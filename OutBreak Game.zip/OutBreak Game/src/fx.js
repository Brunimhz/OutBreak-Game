// =============================================================
// EFEITOS VISUAIS: números flutuantes, partículas de DNA,
// contadores animados, tremida de erro e fundo com partículas.
// =============================================================

export const motion = { reduced: false }

const layer = () => document.getElementById('fx-layer')

export function centerOf(el) {
  const r = el.getBoundingClientRect()
  return { x: r.left + r.width / 2, y: r.top + r.height / 2 }
}

/** Texto que sobe e desaparece ("+100", "-2 DNA"...). */
export function floatText(text, point, tone = 'pos') {
  if (!point) return
  const el = document.createElement('div')
  el.className = `float-text float-${tone}`
  el.textContent = text
  el.style.left = `${point.x}px`
  el.style.top = `${point.y}px`
  layer().appendChild(el)
  const duration = motion.reduced ? 700 : 1300
  el.animate(
    [
      { transform: 'translate(-50%, -50%) scale(.8)', opacity: 0 },
      { transform: 'translate(-50%, -120%) scale(1.05)', opacity: 1, offset: 0.2 },
      { transform: 'translate(-50%, -260%) scale(1)', opacity: 0 },
    ],
    { duration, easing: 'cubic-bezier(.2,.8,.2,1)' },
  ).onfinish = () => el.remove()
}

/** Partículas que voam de um ponto até um elemento (ex.: contador de DNA). */
export function particleBurst(from, targetEl, count = 6, onArrive) {
  if (!from || !targetEl) return onArrive?.()
  const to = centerOf(targetEl)
  if (motion.reduced) return onArrive?.()
  let arrived = 0
  for (let i = 0; i < count; i++) {
    const dot = document.createElement('div')
    dot.className = 'dna-particle'
    dot.style.left = `${from.x}px`
    dot.style.top = `${from.y}px`
    layer().appendChild(dot)
    const spreadX = (Math.random() - 0.5) * 90
    const spreadY = (Math.random() - 0.5) * 90 - 30
    const dx = to.x - from.x
    const dy = to.y - from.y
    dot.animate(
      [
        { transform: 'translate(-50%,-50%) scale(0.4)', opacity: 0 },
        { transform: `translate(calc(-50% + ${spreadX}px), calc(-50% + ${spreadY}px)) scale(1.1)`, opacity: 1, offset: 0.3 },
        { transform: `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px)) scale(0.5)`, opacity: 0.9 },
      ],
      { duration: 750 + i * 60, easing: 'cubic-bezier(.5,0,.3,1)', delay: i * 25 },
    ).onfinish = () => {
      dot.remove()
      arrived++
      if (arrived === count) onArrive?.()
    }
  }
}

/** Faz um número "rolar" do valor antigo ao novo. */
const tweens = new WeakMap()
export function animateNumber(el, from, to, duration = 600) {
  if (!el) return
  cancelAnimationFrame(tweens.get(el))
  if (motion.reduced || from === to) {
    el.textContent = to.toLocaleString('pt-BR')
    return
  }
  const start = performance.now()
  const step = (now) => {
    const t = Math.min(1, (now - start) / duration)
    const eased = 1 - Math.pow(1 - t, 3)
    el.textContent = Math.round(from + (to - from) * eased).toLocaleString('pt-BR')
    if (t < 1) tweens.set(el, requestAnimationFrame(step))
  }
  tweens.set(el, requestAnimationFrame(step))
}

export function bump(el, cls = 'is-bumped') {
  if (!el) return
  el.classList.remove(cls)
  void el.offsetWidth // reinicia a animação CSS
  el.classList.add(cls)
}

export function shake(el) {
  bump(el, 'is-shaking')
}

/** Explosão de fragmentos para a tela de vitória. */
export function celebrate() {
  if (motion.reduced) return
  const cx = window.innerWidth / 2
  const cy = window.innerHeight / 2.4
  const colors = ['#3ee6c4', '#f5b84a', '#ff4d6a', '#8ab4ff']
  for (let i = 0; i < 42; i++) {
    const shard = document.createElement('div')
    shard.className = 'shard'
    shard.style.left = `${cx}px`
    shard.style.top = `${cy}px`
    shard.style.background = colors[i % colors.length]
    layer().appendChild(shard)
    const angle = (Math.PI * 2 * i) / 42 + Math.random() * 0.3
    const dist = 180 + Math.random() * 260
    shard.animate(
      [
        { transform: 'translate(-50%,-50%) rotate(0deg) scale(1)', opacity: 1 },
        {
          transform: `translate(calc(-50% + ${Math.cos(angle) * dist}px), calc(-50% + ${Math.sin(angle) * dist}px)) rotate(${Math.random() * 540}deg) scale(.4)`,
          opacity: 0,
        },
      ],
      { duration: 1400 + Math.random() * 600, easing: 'cubic-bezier(.1,.8,.3,1)' },
    ).onfinish = () => shard.remove()
  }
}

// ---------- Fundo com partículas (canvas) ----------
export function initBackground(canvas) {
  const ctx = canvas.getContext('2d')
  let width = 0
  let height = 0
  let particles = []
  let frame = 0

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    width = window.innerWidth
    height = window.innerHeight
    canvas.width = width * dpr
    canvas.height = height * dpr
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    const count = Math.min(60, Math.floor((width * height) / 26000))
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.18,
      vy: (Math.random() - 0.5) * 0.18,
      r: Math.random() * 1.4 + 0.4,
    }))
    draw()
  }

  function draw() {
    ctx.clearRect(0, 0, width, height)
    for (let i = 0; i < particles.length; i++) {
      const p = particles[i]
      for (let j = i + 1; j < particles.length; j++) {
        const q = particles[j]
        const d = Math.hypot(p.x - q.x, p.y - q.y)
        if (d < 120) {
          ctx.strokeStyle = `rgba(110, 200, 220, ${0.08 * (1 - d / 120)})`
          ctx.lineWidth = 1
          ctx.beginPath()
          ctx.moveTo(p.x, p.y)
          ctx.lineTo(q.x, q.y)
          ctx.stroke()
        }
      }
      ctx.fillStyle = 'rgba(160, 230, 230, 0.55)'
      ctx.beginPath()
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  function tick() {
    if (!motion.reduced && !document.hidden) {
      for (const p of particles) {
        p.x += p.vx
        p.y += p.vy
        if (p.x < 0 || p.x > width) p.vx *= -1
        if (p.y < 0 || p.y > height) p.vy *= -1
      }
      draw()
    }
    frame = requestAnimationFrame(tick)
  }

  window.addEventListener('resize', resize)
  resize()
  cancelAnimationFrame(frame)
  frame = requestAnimationFrame(tick)
}
