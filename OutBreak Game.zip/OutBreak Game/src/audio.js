// =============================================================
// EFEITOS SONOROS com Web Audio API (sem arquivos de áudio).
// Começa DESLIGADO; o jogador liga em Configurações ou no HUD.
// =============================================================
let ctx = null
let enabled = false

function ensureContext() {
  if (!ctx) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext
    if (!AudioCtx) return null
    ctx = new AudioCtx()
  }
  if (ctx.state === 'suspended') ctx.resume()
  return ctx
}

export function setSoundEnabled(value) {
  enabled = value
  if (enabled) ensureContext()
}

function tone(freq, duration, { type = 'sine', volume = 0.06, delay = 0, slideTo = null } = {}) {
  if (!enabled) return
  const audio = ensureContext()
  if (!audio) return
  const start = audio.currentTime + delay
  const osc = audio.createOscillator()
  const gain = audio.createGain()
  osc.type = type
  osc.frequency.setValueAtTime(freq, start)
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, start + duration)
  gain.gain.setValueAtTime(0.0001, start)
  gain.gain.exponentialRampToValueAtTime(volume, start + 0.01)
  gain.gain.exponentialRampToValueAtTime(0.0001, start + duration)
  osc.connect(gain).connect(audio.destination)
  osc.start(start)
  osc.stop(start + duration + 0.05)
}

export const sfx = {
  click: () => tone(720, 0.05, { type: 'triangle', volume: 0.035 }),
  select: () => {
    tone(540, 0.06, { type: 'triangle', volume: 0.04 })
    tone(810, 0.08, { type: 'triangle', volume: 0.03, delay: 0.04 })
  },
  confirm: () => {
    tone(520, 0.09, { volume: 0.05 })
    tone(780, 0.14, { volume: 0.05, delay: 0.07 })
  },
  error: () => tone(150, 0.2, { type: 'sawtooth', volume: 0.04, slideTo: 110 }),
  travel: () => tone(300, 0.6, { type: 'sine', volume: 0.04, slideTo: 900 }),
  dna: () => {
    tone(880, 0.06, { type: 'triangle', volume: 0.035 })
    tone(1320, 0.08, { type: 'triangle', volume: 0.03, delay: 0.05 })
  },
  objective: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.2, { volume: 0.05, delay: i * 0.08 })),
  unlock: () => {
    tone(220, 0.45, { type: 'sawtooth', volume: 0.025, slideTo: 1100 })
    tone(1100, 0.25, { type: 'triangle', volume: 0.04, delay: 0.4 })
  },
  event: () => {
    tone(110, 0.45, { type: 'square', volume: 0.025 })
    tone(220, 0.3, { type: 'triangle', volume: 0.04, delay: 0.12 })
  },
  turn: () => {
    tone(330, 0.12, { volume: 0.04 })
    tone(495, 0.16, { volume: 0.04, delay: 0.1 })
  },
  victory: () => [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, 0.35, { volume: 0.05, delay: i * 0.12 })),
  defeat: () => [440, 370, 311, 220].forEach((f, i) => tone(f, 0.4, { type: 'triangle', volume: 0.05, delay: i * 0.18 })),
}
