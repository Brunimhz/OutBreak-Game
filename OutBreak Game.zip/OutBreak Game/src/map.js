// =============================================================
// RENDERIZAÇÃO DO MAPA (SVG 2.5D)
// buildMap() cria os elementos uma única vez.
// updateMap() só troca classes/atributos conforme o estado.
// =============================================================
import { CITIES, CITY_BY_ID, REGIONS, ROUTES, ROUTE_BY_ID } from './data.js'
import { getAvailableExpansions, getCityPeople, getCityStatus, STATUS_LABELS } from './rules.js'
import { motion } from './fx.js'

const NS = 'http://www.w3.org/2000/svg'
const DOT_BUCKETS = 14
const refs = { svg: null, routes: {}, cities: {}, fx: null, landBuckets: {}, glows: {} }
let demoTimer = null
let trafficTimer = null

function svgEl(tag, attrs = {}, parent = null) {
  const el = document.createElementNS(NS, tag)
  for (const [key, value] of Object.entries(attrs)) el.setAttribute(key, value)
  if (parent) parent.appendChild(el)
  return el
}

// Ruído determinístico para deixar as bordas dos continentes orgânicas
const noise = (x, y) => Math.sin(x * 0.045 + y * 0.021) * 0.5 + Math.cos(y * 0.061 - x * 0.013) * 0.5

function blobDistance(blobs, x, y) {
  return Math.min(...blobs.map(([cx, cy, rx, ry]) => ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2))
}

/** Curva quadrática entre duas cidades; rotas longas curvam mais. */
function routeGeometry(route) {
  const a = CITY_BY_ID[route.a]
  const b = CITY_BY_ID[route.b]
  const mx = (a.x + b.x) / 2
  const my = (a.y + b.y) / 2
  const dx = b.x - a.x
  const dy = b.y - a.y
  const dist = Math.hypot(dx, dy)
  const bend = dist * (route.cost === 1 ? 0.06 : 0.15) * (route.index % 2 === 0 ? 1 : -1)
  const cx = mx + (-dy / dist) * bend
  const cy = my + (dx / dist) * bend
  return {
    d: `M ${a.x} ${a.y} Q ${cx.toFixed(1)} ${cy.toFixed(1)} ${b.x} ${b.y}`,
    mid: { x: 0.25 * a.x + 0.5 * cx + 0.25 * b.x, y: 0.25 * a.y + 0.5 * cy + 0.25 * b.y },
  }
}

export function buildMap(svg) {
  refs.svg = svg
  svg.innerHTML = ''

  // ----- Definições: gradientes e filtros -----
  const defs = svgEl('defs', {}, svg)
  defs.innerHTML = `
    <radialGradient id="ocean" cx="50%" cy="45%" r="70%">
      <stop offset="0%" stop-color="#0d1a2b"/>
      <stop offset="100%" stop-color="#060a12" stop-opacity="0"/>
    </radialGradient>
    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(120,170,210,0.07)" stroke-width="1"/>
    </pattern>
    <linearGradient id="beam" x1="0" y1="1" x2="0" y2="0">
      <stop offset="0%" stop-color="#ff4d6a" stop-opacity="0.9"/>
      <stop offset="100%" stop-color="#ff4d6a" stop-opacity="0"/>
    </linearGradient>
    <radialGradient id="infectGlow">
      <stop offset="0%" stop-color="#ff2d4f" stop-opacity="0.55"/>
      <stop offset="55%" stop-color="#ff2d4f" stop-opacity="0.16"/>
      <stop offset="100%" stop-color="#ff2d4f" stop-opacity="0"/>
    </radialGradient>
    <filter id="shadowBlur" x="-30%" y="-30%" width="160%" height="160%">
      <feGaussianBlur stdDeviation="10"/>
    </filter>
    <filter id="glow" x="-100%" y="-100%" width="300%" height="300%">
      <feGaussianBlur stdDeviation="3" result="b"/>
      <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    ${REGIONS.map(
      (r) => `<radialGradient id="glow-${r.id}"><stop offset="0%" stop-color="${r.color}" stop-opacity="0.16"/><stop offset="100%" stop-color="${r.color}" stop-opacity="0"/></radialGradient>`,
    ).join('')}
  `

  svgEl('rect', { x: -200, y: -200, width: 1400, height: 1000, fill: 'url(#ocean)' }, svg)
  svgEl('rect', { x: 0, y: 0, width: 1000, height: 600, fill: 'url(#grid)', class: 'map-grid' }, svg)

  // ----- Sombras dos continentes (sensação de profundidade) -----
  const shadows = svgEl('g', { class: 'land-shadow', filter: 'url(#shadowBlur)' }, svg)
  for (const region of REGIONS) {
    for (const [cx, cy, rx, ry] of region.blobs) {
      svgEl('ellipse', { cx, cy: cy + 14, rx: rx * 0.95, ry: ry * 0.9 }, shadows)
    }
  }

  // ----- Graticule (meridianos/paralelos curvos, dá cara de globo) -----
  const grat = svgEl('g', { class: 'graticule' }, svg)
  for (let y = 100; y < 600; y += 100) svgEl('line', { x1: 0, y1: y, x2: 1000, y2: y }, grat)
  for (const rx of [120, 280, 440, 600]) svgEl('ellipse', { cx: 500, cy: 300, rx, ry: 360 }, grat)
  svgEl('line', { x1: 500, y1: 0, x2: 500, y2: 600 }, grat)

  // ----- Continentes em pontos -----
  // Cada ponto pertence à cidade mais próxima da sua região. Os pontos de
  // cada cidade são ordenados pela distância até ela e agrupados em faixas
  // (buckets): assim a infecção "escorre" a partir da cidade, como no Plague Inc.
  const land = svgEl('g', { class: 'land' }, svg)
  const STEP = 11
  const fine = (x, y) => Math.sin(x * 0.13 + y * 0.07) * Math.cos(y * 0.11 - x * 0.05)
  const dotsByCity = Object.fromEntries(CITIES.map((c) => [c.id, []]))
  const citiesByRegion = Object.fromEntries(REGIONS.map((r) => [r.id, CITIES.filter((c) => c.region === r.id)]))

  for (let row = 0, y = 6; y < 600; row++, y += STEP * 0.866) {
    for (let x = (row % 2) * (STEP / 2); x < 1000; x += STEP) {
      let best = null
      let bestRatio = 1
      for (const region of REGIONS) {
        const ratio = blobDistance(region.blobs, x, y) / (1 + noise(x, y) * 0.22 + fine(x, y) * 0.08)
        if (ratio < bestRatio) {
          bestRatio = ratio
          best = region
        }
      }
      if (!best) continue
      let city = null
      let cityDist = Infinity
      for (const c of citiesByRegion[best.id]) {
        const d = Math.hypot(c.x - x, c.y - y)
        if (d < cityDist) {
          cityDist = d
          city = c
        }
      }
      const r = bestRatio < 0.55 ? 1.9 : bestRatio < 0.85 ? 1.55 : 1.15
      dotsByCity[city.id].push({ x, y, r, key: cityDist * (1 + 0.3 * noise(x * 1.7, y * 1.3)) })
    }
  }

  refs.landBuckets = {}
  for (const region of REGIONS) {
    const group = svgEl('g', { class: `land-region region-${region.id}`, style: `--rc:${region.color}` }, land)
    for (const [cx, cy, rx, ry] of region.blobs) {
      svgEl('ellipse', { cx, cy, rx: rx * 1.1, ry: ry * 1.1, fill: `url(#glow-${region.id})` }, group)
    }
    for (const city of citiesByRegion[region.id]) {
      const dots = dotsByCity[city.id].sort((a, b) => a.key - b.key)
      const size = Math.ceil(dots.length / DOT_BUCKETS) || 1
      refs.landBuckets[city.id] = Array.from({ length: DOT_BUCKETS }, (_, b) => {
        const d = dots
          .slice(b * size, (b + 1) * size)
          .map(({ x, y, r }) => `M${(x - r).toFixed(1)} ${y.toFixed(1)}a${r} ${r} 0 1 0 ${r * 2} 0a${r} ${r} 0 1 0 ${-r * 2} 0`)
          .join('')
        return svgEl('path', { d, class: 'land-dots', style: `--b:${b}` }, group)
      })
    }
    const label = svgEl('text', { x: region.label[0], y: region.label[1], class: 'region-label', 'text-anchor': 'middle' }, group)
    label.textContent = region.name.toUpperCase()
  }

  // ----- Brilho vermelho sob cidades infectadas -----
  const glows = svgEl('g', { class: 'infect-glows' }, svg)
  refs.glows = {}
  for (const city of CITIES) {
    refs.glows[city.id] = svgEl('circle', { cx: city.x, cy: city.y, r: 70, class: 'infect-glow', fill: 'url(#infectGlow)' }, glows)
  }

  // ----- Rotas -----
  const routesGroup = svgEl('g', { class: 'routes' }, svg)
  ROUTES.forEach((route, i) => {
    const geo = routeGeometry(route)
    const g = svgEl(
      'g',
      {
        class: `route type-${route.type}`,
        'data-action': 'select-route',
        'data-route': route.id,
        style: `--i:${i}`,
      },
      routesGroup,
    )
    svgEl('path', { d: geo.d, class: 'route-glow' }, g)
    const line = svgEl('path', { d: geo.d, class: 'route-line' }, g)
    svgEl('path', { d: geo.d, class: 'route-flow' }, g)
    svgEl('path', { d: geo.d, class: 'route-hit' }, g)
    const badge = svgEl('g', { class: 'route-badge', transform: `translate(${geo.mid.x.toFixed(1)} ${geo.mid.y.toFixed(1)})` }, g)
    svgEl('circle', { r: 9 }, badge)
    const cost = svgEl('text', { 'text-anchor': 'middle', dy: '3.6' }, badge)
    cost.textContent = route.cost
    refs.routes[route.id] = { g, line, cost }
  })

  // ----- Cidades -----
  const citiesGroup = svgEl('g', { class: 'cities' }, svg)
  CITIES.forEach((city, i) => {
    const g = svgEl(
      'g',
      {
        class: 'city status-healthy',
        transform: `translate(${city.x} ${city.y})`,
        'data-action': 'select-city',
        'data-city': city.id,
        tabindex: '0',
        role: 'button',
        style: `--i:${i}; --heat:0`,
      },
      citiesGroup,
    )
    const beam = svgEl('rect', { class: 'city-beam', x: -1.5, y: 0, width: 3, height: 0, fill: 'url(#beam)' }, g)
    svgEl('circle', { class: 'city-halo', r: 16 }, g)
    svgEl('circle', { class: 'city-ring', r: 12 }, g)
    svgEl('circle', { class: 'city-sel', r: 20 }, g)
    const core = svgEl('circle', { class: 'city-core', r: 5.5 }, g)
    svgEl('circle', { class: 'city-hit', r: 22 }, g)
    const label = svgEl('text', { class: 'city-label', 'text-anchor': 'middle', y: city.labelBelow ? 24 : -14 }, g)
    label.textContent = city.name
    const tag = svgEl('text', { class: 'city-tag', 'text-anchor': 'middle', y: city.labelBelow ? 35 : 22 }, g)
    refs.cities[city.id] = { g, core, tag, beam }
  })

  refs.fx = svgEl('g', { class: 'map-fx' }, svg)
}

export function updateMap(state) {
  const playing = state.phase === 'playing'
  const options = playing ? getAvailableExpansions(state) : []
  const optionByRoute = new Map(options.map((o) => [o.routeId, o]))
  const sel = state.selectedCity
  const selRoute = state.selectedRoute
  const reachable = new Set(options.map((o) => o.to))

  for (const route of ROUTES) {
    const { g, cost } = refs.routes[route.id]
    const option = optionByRoute.get(route.id)
    const touchesSel = sel && (route.a === sel || route.b === sel)
    const toBlocked =
      state.modifiers.blockedRegion &&
      (CITY_BY_ID[route.a].region === state.modifiers.blockedRegion ||
        CITY_BY_ID[route.b].region === state.modifiers.blockedRegion)
    g.classList.toggle('is-owned', state.ownedRoutes.includes(route.id))
    g.classList.toggle('is-available', !!option)
    g.classList.toggle('is-focus', !!option && (state.expandMode || touchesSel))
    g.classList.toggle('is-related', !!touchesSel)
    g.classList.toggle('is-dim', !!sel && !touchesSel && !state.expandMode)
    g.classList.toggle('is-selected', selRoute?.routeId === route.id)
    g.classList.toggle('is-restricted', state.modifiers.restrictedRoutes.includes(route.id))
    g.classList.toggle('is-blocked', !!toBlocked)
    cost.textContent = option ? option.cost : route.cost
  }

  for (const city of CITIES) {
    const { g, tag, beam } = refs.cities[city.id]
    const cs = state.cities[city.id]
    const status = getCityStatus(state, city.id)
    g.setAttribute('class', `city status-${status}`)
    g.classList.toggle('is-selected', sel === city.id)
    g.classList.toggle('is-origin', state.originCity === city.id)
    g.classList.toggle('is-target', selRoute?.to === city.id || selRoute?.from === city.id)
    g.classList.toggle('is-reachable', state.expandMode && reachable.has(city.id))
    g.classList.toggle('is-pickable', state.phase === 'setup')
    const heat = cs.status === 'infected' ? cs.infection / 100 : 0
    g.style.setProperty('--heat', heat.toFixed(2))
    const beamHeight = cs.status === 'infected' ? 10 + heat * 34 : 0
    beam.setAttribute('y', -beamHeight)
    beam.setAttribute('height', beamHeight)
    paintLand(state, city.id, status)
    const label = STATUS_LABELS[status]
    tag.textContent = cs.status === 'infected' ? `${label.toUpperCase()} ${cs.infection}%` : label.toUpperCase()
    g.setAttribute('aria-label', `${city.name}: ${label}${cs.status === 'infected' ? `, infecção ${cs.infection}%` : ''}`)
  }
}

/** Pinta os pontos de terra da cidade: mortos (vinho), infectados (vermelho), saudáveis. */
function paintLand(state, cityId, status) {
  const buckets = refs.landBuckets[cityId]
  if (!buckets) return
  const cs = state.cities[cityId]
  const p = getCityPeople(state, cityId)
  const deadN = p.dead > 0 ? Math.max(1, Math.round((p.dead / p.total) * DOT_BUCKETS)) : 0
  const infN = p.infected > 0 ? Math.min(DOT_BUCKETS - deadN, Math.max(1, Math.ceil((p.infected / p.total) * DOT_BUCKETS))) : 0
  buckets.forEach((path, b) => {
    let cls = 'land-dots'
    if (b < deadN) cls += ' is-dead'
    else if (b < deadN + infN) cls += cs.status === 'contained' ? ' is-contained' : ' is-infected'
    else if (b === 0 && status === 'exposed') cls += ' is-exposed'
    path.setAttribute('class', cls)
  })
  const glow = refs.glows[cityId]
  const level = cs.status === 'infected' ? (p.infected + p.dead) / p.total : 0
  glow.style.opacity = (level * 0.9).toFixed(2)
  glow.setAttribute('r', (40 + level * 70).toFixed(0))
}

// ----- Tráfego mundial: aviões, navios e veículos levando passageiros -----
const PLANE = 'M0 -6 L1.4 -1.5 L6 1 L6 2.2 L1.4 1 L1 4.4 L2.6 5.6 L2.6 6.4 L0 5.6 L-2.6 6.4 L-2.6 5.6 L-1 4.4 L-1.4 1 L-6 2.2 L-6 1 L-1.4 -1.5 Z'
const SHIP = 'M0 -5.5 L2.4 -2 L2.4 4 L0 5.5 L-2.4 4 L-2.4 -2 Z'

export function startTraffic(getState) {
  stopTraffic()
  trafficTimer = setInterval(() => spawnVehicle(getState()), 850)
}

export function stopTraffic() {
  clearInterval(trafficTimer)
  trafficTimer = null
}

function spawnVehicle(state) {
  if (!refs.fx || motion.reduced || document.hidden) return
  if (refs.fx.querySelectorAll('.vehicle').length >= 7) return
  const route = ROUTES[Math.floor(Math.random() * ROUTES.length)]
  const statusA = state?.cities[route.a]?.status
  const statusB = state?.cities[route.b]?.status
  if (statusA === 'contained' && statusB === 'contained') return

  const infectedEnd = statusA === 'infected' ? route.a : statusB === 'infected' ? route.b : null
  const from = infectedEnd && Math.random() < 0.7 ? infectedEnd : Math.random() < 0.5 ? route.a : route.b
  const carrying = state?.cities[from]?.status === 'infected'
  const line = refs.routes[route.id].line
  const length = line.getTotalLength()
  const reverse = route.a !== from
  const kind = route.type === 'hard' ? 'plane' : route.type === 'long' ? 'ship' : 'ground'

  const v = svgEl('g', { class: `vehicle vehicle-${kind}${carrying ? ' is-carrier' : ''}` }, refs.fx)
  if (kind === 'ground') svgEl('circle', { r: 2.2 }, v)
  else svgEl('path', { d: kind === 'plane' ? PLANE : SHIP }, v)

  const duration = kind === 'plane' ? 2600 : kind === 'ship' ? 5200 : 3200
  const start = performance.now()
  const step = (now) => {
    if (!v.isConnected) return
    const t = Math.min(1, (now - start) / duration)
    const dist = (reverse ? 1 - t : t) * length
    const p = line.getPointAtLength(dist)
    const q = line.getPointAtLength(Math.min(length, Math.max(0, dist + (reverse ? -1 : 1))))
    const angle = (Math.atan2(q.y - p.y, q.x - p.x) * 180) / Math.PI + 90
    const scale = kind === 'plane' ? 0.9 + Math.sin(t * Math.PI) * 0.45 : 1
    v.setAttribute('transform', `translate(${p.x.toFixed(1)} ${p.y.toFixed(1)}) rotate(${angle.toFixed(0)}) scale(${scale.toFixed(2)})`)
    v.style.opacity = Math.min(1, Math.min(t, 1 - t) * 8).toFixed(2)
    if (t < 1) requestAnimationFrame(step)
    else v.remove()
  }
  requestAnimationFrame(step)
}

/** Energia percorrendo a rota da origem até o destino. */
export function animateTravel(routeId, fromId, { demo = false } = {}) {
  return new Promise((resolve) => {
    const route = ROUTE_BY_ID[routeId]
    const { line } = refs.routes[routeId]
    if (!line || (motion.reduced && !demo)) return resolve()
    const length = line.getTotalLength()
    const reverse = route.a !== fromId
    const trail = svgEl('path', { d: line.getAttribute('d'), class: `travel-trail${demo ? ' is-demo' : ''}` }, refs.fx)
    trail.style.strokeDasharray = `${length} ${length}`
    const head = svgEl('circle', { r: demo ? 3 : 5, class: `travel-head${demo ? ' is-demo' : ''}` }, refs.fx)
    const duration = demo ? 1600 : 750
    const start = performance.now()

    const step = (now) => {
      const t = Math.min(1, (now - start) / duration)
      const eased = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2
      const dist = eased * length
      const point = line.getPointAtLength(reverse ? length - dist : dist)
      head.setAttribute('cx', point.x)
      head.setAttribute('cy', point.y)
      trail.style.strokeDashoffset = reverse ? -(length - dist) : length - dist
      if (t < 1) return requestAnimationFrame(step)
      head.remove()
      trail.classList.add('is-fading')
      setTimeout(() => trail.remove(), 700)
      resolve()
    }
    requestAnimationFrame(step)
  })
}

/** Onda circular saindo de uma cidade. */
export function pingCity(cityId, kind = 'infect') {
  const city = CITY_BY_ID[cityId]
  if (!city || !refs.fx) return
  const ring = svgEl('circle', { cx: city.x, cy: city.y, r: 6, class: `ping ping-${kind}` }, refs.fx)
  setTimeout(() => ring.remove(), motion.reduced ? 300 : 1100)
}

export function flashRoute(routeId) {
  const ref = refs.routes[routeId]
  if (!ref) return
  ref.g.classList.remove('is-denied')
  void ref.g.getBoundingClientRect()
  ref.g.classList.add('is-denied')
  setTimeout(() => ref.g.classList.remove('is-denied'), 600)
}

export function getCityScreenPoint(cityId) {
  const ref = refs.cities[cityId]
  if (!ref) return null
  const r = ref.core.getBoundingClientRect()
  return { x: r.left + r.width / 2, y: r.top + r.height / 2 }
}

export function focusCity(cityId) {
  refs.cities[cityId]?.g.focus({ preventScroll: true })
}

/** Rola o mapa (no celular) para mostrar uma cidade. */
export function scrollToCity(cityId, stage) {
  const point = getCityScreenPoint(cityId)
  if (!point || stage.scrollWidth <= stage.clientWidth) return
  const rect = stage.getBoundingClientRect()
  stage.scrollBy({ left: point.x - rect.left - rect.width / 2, behavior: motion.reduced ? 'auto' : 'smooth' })
}

// ----- Demonstração animada no menu inicial -----
export function startMenuDemo() {
  stopMenuDemo()
  const run = () => {
    if (motion.reduced) return
    const route = ROUTES[Math.floor(Math.random() * ROUTES.length)]
    animateTravel(route.id, Math.random() > 0.5 ? route.a : route.b, { demo: true })
    const city = CITIES[Math.floor(Math.random() * CITIES.length)]
    pingCity(city.id, 'demo')
  }
  demoTimer = setInterval(run, 1100)
  setTimeout(run, 900)
}

export function stopMenuDemo() {
  clearInterval(demoTimer)
  demoTimer = null
}
