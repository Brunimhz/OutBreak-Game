// =============================================================
// INTERFACE (HUD, painéis, laboratório, telas finais)
// Cada função lê o estado e reescreve sua parte da tela.
// =============================================================
import { icon } from './icons.js'
import { CITIES, CITY_BY_ID, CONFIG, EVOLUTIONS, OBJECTIVES, REGIONS, REGION_BY_ID, ROUTES_BY_CITY } from './data.js'
import * as R from './rules.js'
import { animateNumber, bump } from './fx.js'

const $ = (sel) => document.querySelector(sel)
const pad = (n) => String(n).padStart(2, '0')
const formatPopulation = (m) =>
  `${m.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} milhões`

const formatPeople = (n) => n.toLocaleString('pt-BR')

const shown = { dna: null, score: null, research: null, healthy: null, infected: null, dead: null }

export function resetShownValues() {
  for (const key of Object.keys(shown)) shown[key] = null
}

// ---------- Contador mundial (estilo Plague Inc) ----------
export function renderWorld(state) {
  const w = R.getWorldStats(state)
  for (const key of ['healthy', 'infected', 'dead']) {
    const el = $(`#world-${key}`)
    const previous = shown[key] ?? w[key]
    animateNumber(el, previous, w[key], 1400)
    if (shown[key] !== null && w[key] > shown[key] && key !== 'healthy') bump(el.parentElement)
    shown[key] = w[key]
  }
  const deadPct = (w.dead / w.total) * 100
  const infPct = (w.infected / w.total) * 100
  $('#world-bar-dead').style.width = `${deadPct}%`
  $('#world-bar-infected').style.width = `${infPct}%`
  $('#world-bar').setAttribute(
    'aria-label',
    `${formatPeople(w.healthy)} saudáveis, ${formatPeople(w.infected)} infectados, ${formatPeople(w.dead)} mortos`,
  )
}

// ---------- HUD ----------
export function renderHUD(state) {
  $('#hud-turn').textContent = `${pad(state.currentTurn)} / ${CONFIG.maxTurns}`
  const total = Math.max(CONFIG.actionsPerTurn, state.actionsRemaining)
  const pips = $('#hud-pips')
  pips.innerHTML = Array.from(
    { length: total },
    (_, i) => `<span class="pip${i < state.actionsRemaining ? ' is-on' : ''}${i >= CONFIG.actionsPerTurn ? ' is-extra' : ''}"></span>`,
  ).join('')
  pips.setAttribute('aria-label', `${state.actionsRemaining} ações restantes`)

  updateCounter('dna', $('#hud-dna'), state.dna, $('#stat-dna'))
  updateCounter('score', $('#hud-score'), state.score, $('#stat-score'))

  const research = $('#research')
  const status = R.getResearchStatus(state.research)
  research.dataset.level = status.level
  $('#research-fill').style.width = `${state.research}%`
  $('#research-status').textContent = status.label
  research.querySelector('[role="progressbar"]').setAttribute('aria-valuenow', state.research)
  if (shown.research !== state.research) {
    animateNumber($('#research-value'), shown.research ?? state.research, state.research, 800)
    if (shown.research !== null && state.research > shown.research) bump(research, 'is-pulsing')
    shown.research = state.research
  }
}

function updateCounter(key, el, value, container) {
  if (shown[key] === value) return
  animateNumber(el, shown[key] ?? value, value)
  if (shown[key] !== null) bump(container)
  shown[key] = value
}

// ---------- Objetivos / evento / registro ----------
export function renderObjectives(state) {
  const item = (o) => {
    const done = state.objectives[o.id]
    const p = R.getObjectiveProgress(state, o.id)
    let progress
    let ratio = Math.min(1, p.value / p.target)
    let expired = false
    if (o.id === 'early') {
      expired = !done && state.currentTurn >= 12
      progress = done ? 'Concluído' : expired ? 'Expirado' : `Turno atual: ${pad(state.currentTurn)}`
      ratio = done ? 1 : Math.max(0, (12 - state.currentTurn) / 11)
    } else if (o.id === 'bank') {
      progress = done ? 'Concluído' : `${state.dna}/15 DNA · avaliado no fim`
    } else {
      progress = `${Math.min(p.value, p.target)}/${p.target}`
    }
    return `<li class="obj${done ? ' is-done' : ''}${expired ? ' is-expired' : ''}" data-obj="${o.id}">
      <span class="obj-check">${done ? icon('check', 14) : ''}</span>
      <div class="obj-body">
        <span class="obj-label">${o.label}</span>
        <span class="obj-progress">${progress}</span>
        <span class="obj-bar"><span style="width:${(done ? 1 : ratio) * 100}%"></span></span>
      </div>
      <span class="sr-only">${done ? 'concluído' : 'pendente'}</span>
    </li>`
  }
  $('#obj-main').innerHTML = OBJECTIVES.filter((o) => o.type === 'main').map(item).join('')
  $('#obj-bonus').innerHTML = OBJECTIVES.filter((o) => o.type === 'bonus').map(item).join('')
  const doneMain = OBJECTIVES.filter((o) => o.type === 'main' && state.objectives[o.id]).length
  $('#obj-count').textContent = `${doneMain}/3`
}

export function flashObjective(id) {
  bump(document.querySelector(`[data-obj="${id}"]`), 'is-celebrating')
}

export function renderEvent(state) {
  const ev = state.activeEvent
  const chips = []
  if (ev) {
    chips.push(`<div class="event-chip tone-${ev.tone}">
      <span class="event-icon">${icon(ev.icon, 16)}</span>
      <div><p class="eyebrow">Evento ativo</p><strong>${ev.name}</strong><p>${ev.detail}</p></div>
    </div>`)
  } else {
    chips.push(`<div class="event-chip is-empty"><span class="event-icon">${icon('globe', 16)}</span>
      <div><p class="eyebrow">Evento ativo</p><p>Nenhum evento global no momento.</p></div></div>`)
  }
  if (state.bonuses.freeExpansion) {
    chips.push(`<div class="event-chip tone-good"><span class="event-icon">${icon('shuffle', 16)}</span>
      <div><p class="eyebrow">Mutação ativa</p><strong>Próxima expansão gratuita</strong></div></div>`)
  }
  $('#event-slot').innerHTML = chips.join('')
}

export function renderLog(state) {
  const entries = state.log.slice(0, 8)
  $('#log-list').innerHTML = entries.length
    ? entries
        .map((e) => `<li class="log-item tone-${e.tone}"><span class="log-turn">T${pad(e.turn)}</span><span>${e.text}</span></li>`)
        .join('')
    : '<li class="log-item is-empty">Os acontecimentos da partida aparecem aqui.</li>'
}

// ---------- Painel lateral ----------
const stateChip = (status) =>
  `<span class="state-chip state-${status}"><span class="state-dot"></span>${R.STATUS_LABELS[status]}</span>`

function cityStats(state, cityId) {
  const city = CITY_BY_ID[cityId]
  const cs = state.cities[cityId]
  const status = R.getCityStatus(state, cityId)
  const people = R.getCityPeople(state, cityId)
  return `
    <dl class="city-stats">
      <div><dt>Região</dt><dd>${REGION_BY_ID[city.region].name}</dd></div>
      <div><dt>População</dt><dd>${formatPopulation(city.population)}</dd></div>
      <div><dt>Conexões</dt><dd>${ROUTES_BY_CITY[cityId].length} rotas</dd></div>
      <div><dt>Estado</dt><dd>${R.STATUS_LABELS[status]}${state.originCity === cityId ? ' · Origem' : ''}</dd></div>
      <div class="is-infected"><dt>Infectados</dt><dd>${formatPeople(people.infected)}</dd></div>
      <div class="is-dead"><dt>Mortos</dt><dd>${formatPeople(people.dead)}</dd></div>
    </dl>
    <div class="meter meter-infect">
      <div class="meter-head"><span>Infecção</span><strong>${cs.infection}%</strong></div>
      <div class="meter-track"><span style="width:${cs.infection}%"></span></div>
    </div>
    <div class="meter meter-contain">
      <div class="meter-head"><span>Contenção</span><strong>${cs.containment}%</strong></div>
      <div class="meter-track"><span style="width:${cs.containment}%"></span></div>
    </div>`
}

function panelHead(eyebrow, title, chip = '') {
  return `<div class="panel-head">
    <div class="panel-head-text">${chip || `<p class="eyebrow">${eyebrow}</p>`}<h2 class="panel-title">${title}</h2></div>
    <button class="icon-btn panel-close" data-action="deselect" aria-label="Fechar painel">${icon('x', 18)}</button>
  </div>`
}

function routePreview(state) {
  const sel = state.selectedRoute
  if (!sel) return ''
  const option = R.getAvailableExpansions(state).find((o) => o.routeId === sel.routeId)
  if (!option) return ''
  const notes = []
  if (state.bonuses.freeExpansion) notes.push('Mutação: expansão gratuita')
  if (state.modifiers.restrictedRoutes.includes(option.routeId)) notes.push('Restrição de viagem: +1 DNA')
  if (state.modifiers.blockedRegion === CITY_BY_ID[option.to].region && state.evolutions.env < 1)
    notes.push('Bloqueio regional: +1 DNA')
  const short = option.cost > state.dna
  return `<section class="route-preview" aria-label="Rota selecionada">
    <p class="eyebrow">Rota selecionada</p>
    <div class="rp-path">
      <span class="rp-city">${CITY_BY_ID[option.from].name}</span>
      <span class="rp-line type-${option.route.type}"></span>
      <span class="rp-city is-target">${CITY_BY_ID[option.to].name}</span>
    </div>
    <dl class="rp-stats">
      <div><dt>Tipo</dt><dd>${option.route.typeLabel}</dd></div>
      <div><dt>Custo</dt><dd class="${short ? 'is-short' : ''}">${option.cost} DNA</dd></div>
      <div><dt>Recompensa</dt><dd>+${option.rewards.score} pts · +${option.rewards.dna} DNA</dd></div>
      <div><dt>Pesquisa</dt><dd>+${option.rewards.research}%</dd></div>
    </dl>
    ${notes.length ? `<p class="rp-notes">${notes.join(' · ')}</p>` : ''}
    ${option.rewards.newRegion ? `<p class="rp-region">${icon('globe', 14)} Nova região: ${REGION_BY_ID[CITY_BY_ID[option.to].region].name}</p>` : ''}
    <div class="rp-actions">
      <button class="btn btn-primary" data-action="confirm-expand">${icon('check', 16)} Confirmar Expansão</button>
      <button class="btn btn-ghost" data-action="cancel-route">Cancelar</button>
    </div>
  </section>`
}

function optionButton(state, o) {
  const selected = state.selectedRoute?.routeId === o.routeId
  return `<li><button class="option${selected ? ' is-selected' : ''}" data-action="select-route" data-route="${o.routeId}">
    <span class="option-path"><span>${CITY_BY_ID[o.from].name}</span>${icon('arrowRight', 14)}<strong>${CITY_BY_ID[o.to].name}</strong></span>
    <span class="option-meta">
      <span class="type-tag type-${o.route.type}">${o.route.typeLabel}</span>
      ${o.rewards.newRegion ? '<span class="type-tag type-region">Nova região</span>' : ''}
      <span class="cost${o.cost > state.dna ? ' is-short' : ''}">${icon('dna', 13)} ${o.cost}</span>
    </span>
  </button></li>`
}

function setupIntroPanel() {
  const hubs = CITIES.map((c) => ({ c, n: ROUTES_BY_CITY[c.id].length }))
    .sort((a, b) => b.n - a.n)
    .slice(0, 3)
  return `<div class="panel-head"><div class="panel-head-text"><p class="eyebrow">Preparação</p><h2 class="panel-title">Escolha a origem</h2></div></div>
    <p class="panel-note">Clique em qualquer cidade do mapa para definir onde o surto fictício começa. A partir dela, você vai se expandir pelas rotas conectadas.</p>
    <h3 class="panel-sub">Cidades estratégicas</h3>
    <ul class="hub-list">${hubs
      .map(
        ({ c, n }) => `<li><button class="option" data-action="select-city" data-city="${c.id}">
          <span class="option-path"><strong>${c.name}</strong></span>
          <span class="option-meta"><span class="type-tag">${REGION_BY_ID[c.region].name}</span><span class="cost">${icon('route', 13)} ${n}</span></span>
        </button></li>`,
      )
      .join('')}</ul>
    <p class="panel-note subtle">Dica: cidades com muitas conexões oferecem mais caminhos, mas pensem também em quão perto estão de outras regiões.</p>`
}

function setupCityPanel(state) {
  const id = state.selectedCity
  return `${panelHead('Possível origem', CITY_BY_ID[id].name)}
    ${cityStats(state, id)}
    <p class="panel-note">${CITY_BY_ID[id].name} possui ${ROUTES_BY_CITY[id].length} rotas. O surto começa com ${CONFIG.originInfection}% de infecção.</p>
    <button class="btn btn-primary btn-block" data-action="start-outbreak">${icon('crosshair', 18)} Iniciar surto aqui</button>`
}

function cityPanel(state) {
  const id = state.selectedCity
  const status = R.getCityStatus(state, id)
  const options = R.getAvailableExpansions(state)
  const routes = ROUTES_BY_CITY[id]
    .map((route) => {
      const other = route.a === id ? route.b : route.a
      const option = options.find((o) => o.routeId === route.id)
      let label
      let cls
      if (option) {
        label = `${option.cost} DNA`
        cls = 'is-open'
      } else if (state.ownedRoutes.includes(route.id)) {
        label = 'Conectada'
        cls = 'is-owned'
      } else {
        label = 'Indisponível'
        cls = 'is-closed'
      }
      const selected = state.selectedRoute?.routeId === route.id
      return `<li><button class="route-item ${cls}${selected ? ' is-selected' : ''}" data-action="select-route" data-route="${route.id}">
        <span class="ri-dest"><span class="ri-dot status-${R.getCityStatus(state, other)}"></span>${CITY_BY_ID[other].name}</span>
        <span class="type-tag type-${route.type}">${route.typeLabel}</span>
        <span class="ri-state">${label}</span>
      </button></li>`
    })
    .join('')

  const breach =
    status === 'contained'
      ? `<button class="btn btn-contain btn-block" data-action="breach" data-city="${id}">${icon('shield', 16)} Romper Contenção · ${CONFIG.breachCost} DNA</button>`
      : ''

  return `${panelHead('', CITY_BY_ID[id].name, stateChip(status))}
    ${routePreview(state)}
    ${cityStats(state, id)}
    ${breach}
    <h3 class="panel-sub">Rotas</h3>
    <ul class="route-list">${routes}</ul>`
}

function expandPanel(state) {
  const options = R.getAvailableExpansions(state)
  const list = options.length
    ? `<ul class="option-list">${options.map((o) => optionButton(state, o)).join('')}</ul>`
    : `<p class="panel-empty">Nenhuma rota disponível. Use a habilidade Romper Contenção ou aguarde o próximo turno.</p>`
  return `${panelHead('Ação', 'Modo Expansão')}
    <p class="panel-note">Escolha uma rota destacada no mapa ou na lista abaixo. Cada expansão custa 1 ação mais o custo da rota em DNA.</p>
    ${routePreview(state)}
    <h3 class="panel-sub">Rotas disponíveis <span class="count">${options.length}</span></h3>
    ${list}`
}

function overviewPanel(state) {
  const active = R.getActiveCities(state).length
  const contained = CITIES.filter((c) => state.cities[c.id].status === 'contained').length
  const exposed = CITIES.filter((c) => R.getCityStatus(state, c.id) === 'exposed').length
  const routes = R.getAvailableExpansions(state).length
  const regions = REGIONS.map((r) => {
    const cities = CITIES.filter((c) => c.region === r.id)
    const reached = cities.filter((c) => state.cities[c.id].status !== 'healthy').length
    return `<li class="region-row" style="--rc:${r.color}">
      <div class="region-head"><span class="region-dot"></span><span>${r.name}</span><strong>${reached}/${cities.length}</strong></div>
      <div class="meter-track"><span style="width:${(reached / cities.length) * 100}%"></span></div>
    </li>`
  }).join('')

  return `<div class="panel-head"><div class="panel-head-text"><p class="eyebrow">Centro de Comando</p><h2 class="panel-title">Visão Geral</h2></div></div>
    <div class="kpi-grid">
      <div class="kpi kpi-infected"><span>Infectadas</span><strong>${active}</strong></div>
      <div class="kpi kpi-contained"><span>Contidas</span><strong>${contained}</strong></div>
      <div class="kpi kpi-exposed"><span>Expostas</span><strong>${exposed}</strong></div>
      <div class="kpi"><span>Rotas livres</span><strong>${routes}</strong></div>
    </div>
    <h3 class="panel-sub">Regiões</h3>
    <ul class="region-list">${regions}</ul>
    <h3 class="panel-sub">Legenda</h3>
    <ul class="legend">
      <li>${stateChip('healthy')}<span>Ainda não afetada</span></li>
      <li>${stateChip('exposed')}<span>Vizinha do seu território</span></li>
      <li>${stateChip('infected')}<span>Faz parte da expansão</span></li>
      <li>${stateChip('contained')}<span>Bloqueada pela resposta global</span></li>
    </ul>
    <ul class="legend legend-routes">
      <li><span class="rp-line type-normal"></span><span>Normal · 1 DNA</span></li>
      <li><span class="rp-line type-long"></span><span>Longa · 2 DNA</span></li>
      <li><span class="rp-line type-hard"></span><span>Difícil · 3 DNA</span></li>
    </ul>`
}

export function renderPanel(state) {
  const panel = $('#panel-right')
  let html
  if (state.phase === 'setup') html = state.selectedCity ? setupCityPanel(state) : setupIntroPanel()
  else if (state.expandMode) html = expandPanel(state)
  else if (state.selectedCity) html = cityPanel(state)
  else html = overviewPanel(state)
  panel.querySelector('.panel-scroll').innerHTML = html
  panel.classList.toggle('is-open', !!(state.selectedCity || state.expandMode))
}

// ---------- Barra de ações e dica ----------
export function renderActions(state) {
  const playing = state.phase === 'playing'
  const noActions = state.actionsRemaining <= 0
  document.querySelectorAll('.action-btn[data-needs-action]').forEach((btn) => {
    btn.setAttribute('aria-disabled', String(!playing || noActions))
  })
  const expandBtn = $('#act-expand')
  expandBtn.setAttribute('aria-pressed', String(state.expandMode))
  expandBtn.classList.toggle('is-active', state.expandMode)
  $('#collect-gain').textContent = `+${R.getCollectAmount(state)}`
  const endBtn = $('#act-end')
  endBtn.setAttribute('aria-disabled', String(!playing))
  endBtn.classList.toggle('is-ready', playing && noActions)
  $('#action-bar').classList.toggle('is-setup', state.phase === 'setup')
}

export function renderHint(state) {
  let text
  if (state.phase === 'setup') text = 'Clique em uma cidade para escolher a origem do surto.'
  else if (state.phase !== 'playing') text = ''
  else if (state.actionsRemaining <= 0) text = 'Sem ações restantes. Encerre o turno para continuar.'
  else if (state.selectedRoute) text = 'Confirme a expansão para enviar a energia pela rota.'
  else if (state.expandMode) text = 'Escolha uma rota destacada no mapa ou na lista.'
  else if (R.getAvailableExpansions(state).length === 0)
    text = 'Nenhuma rota livre. Rompa uma contenção usando uma Habilidade.'
  else if (state.research >= 70) text = 'Pesquisa em alerta! A Interferência de Dados reduz a pesquisa em 5%.'
  else
    text = `Você tem ${state.actionsRemaining} ${state.actionsRemaining === 1 ? 'ação' : 'ações'}: expanda, evolua ou colete recursos.`
  $('#hint').textContent = text
  $('#hint').hidden = !text
}

// ---------- Laboratório de Evolução ----------
export function renderLab(state, justUnlocked = null) {
  $('#lab-dna').textContent = state.dna
  $('#lab-actions').textContent = state.actionsRemaining
  const tiers = [1, 2, 3]
  $('#lab-body').innerHTML = tiers
    .map((tier) => {
      const nodes = EVOLUTIONS.filter((e) => e.tier === tier)
        .map((evo) => {
          const level = state.evolutions[evo.id]
          const lock = R.getEvolutionLock(state, evo)
          const isMax = level >= evo.maxLevel
          const isLocked = !!lock && !isMax
          const cost = R.getEvolutionCost(state, evo)
          const nextLevel = Math.min(level + 1, evo.maxLevel)
          const pips = Array.from({ length: evo.maxLevel }, (_, i) => `<span class="${i < level ? 'is-on' : ''}"></span>`).join('')
          let button
          if (isMax) button = `<span class="evo-max">${icon('check', 14)} Nível máximo</span>`
          else if (isLocked) button = `<span class="evo-lock">${icon('lock', 14)} ${lock}</span>`
          else {
            const short = state.dna < cost
            button = `<button class="btn btn-evo${short || state.actionsRemaining <= 0 ? ' is-unaffordable' : ''}" data-action="evolve" data-evo="${evo.id}">
              ${level === 0 ? 'Desbloquear' : 'Evoluir'} · ${icon('dna', 14)} ${cost}
            </button>`
          }
          const classes = ['evo-node', level > 0 ? 'is-unlocked' : '', isLocked ? 'is-locked' : '', isMax ? 'is-max' : '', justUnlocked === evo.id ? 'is-just-unlocked' : '']
          return `<article class="${classes.join(' ')}" data-evo-node="${evo.id}">
            <div class="evo-top">
              <span class="evo-icon">${icon(evo.icon, 22)}</span>
              <div><h3 class="evo-name">${evo.name}</h3><p class="evo-level">Nível ${level}/${evo.maxLevel}</p></div>
              <span class="evo-pips" aria-hidden="true">${pips}</span>
            </div>
            <p class="evo-desc">${evo.desc}</p>
            <p class="evo-effect"><span>${isMax ? 'Efeito atual' : `Nível ${nextLevel}`}</span>${evo.effect(isMax ? level : nextLevel)}</p>
            ${button}
          </article>`
        })
        .join('')
      return `<section class="lab-tier" data-tier="${tier}">
        <p class="tier-label">Camada ${['I', 'II', 'III'][tier - 1]}${tier > 1 ? ` · requer ${tier - 1} ${tier === 2 ? 'evolução' : 'evoluções'}` : ''}</p>
        <div class="tier-nodes">${nodes}</div>
      </section>`
    })
    .join('')
}

// ---------- Habilidades ----------
export function renderAbility(state) {
  const contained = CITIES.filter((c) => state.cities[c.id].status === 'contained')
  const breachList = contained.length
    ? `<ul class="ability-targets">${contained
        .map(
          (c) => `<li><button class="option" data-action="breach" data-city="${c.id}">
            <span class="option-path"><strong>${c.name}</strong></span>
            <span class="option-meta"><span class="type-tag">Contenção ${state.cities[c.id].containment}%</span></span>
          </button></li>`,
        )
        .join('')}</ul>`
    : '<p class="panel-empty">Nenhuma cidade contida no momento.</p>'
  const used = state.interferenceUsed
  $('#ability-body').innerHTML = `
    <article class="ability-card">
      <div class="ability-top"><span class="ability-icon is-contain">${icon('shield', 22)}</span>
        <div><h3>Romper Contenção</h3><p class="ability-cost">${icon('dna', 13)} ${CONFIG.breachCost} DNA · 1 ação</p></div></div>
      <p>Uma cidade contida volta a ficar infectada e pode servir novamente como origem de expansões.</p>
      ${breachList}
    </article>
    <article class="ability-card">
      <div class="ability-top"><span class="ability-icon is-research">${icon('activity', 22)}</span>
        <div><h3>Interferência de Dados</h3><p class="ability-cost">${icon('dna', 13)} ${CONFIG.interfereCost} DNA · 1 ação · 1 vez por turno</p></div></div>
      <p>Embaralha os dados da pesquisa internacional. Pesquisa Global −${CONFIG.interfereAmount}%.</p>
      <button class="btn btn-primary btn-block${used ? ' is-unaffordable' : ''}" data-action="interfere">
        ${used ? 'Já usada neste turno' : `Usar Interferência · ${icon('dna', 14)} ${CONFIG.interfereCost}`}
      </button>
    </article>`
}

// ---------- Tela final ----------
export function renderEnd(state) {
  const r = state.result
  const victory = r.type === 'victory'
  const stats = victory
    ? [
        ['Cidades alcançadas', r.cities],
        ['Regiões alcançadas', `${r.regions}/4`],
        ['Evoluções desbloqueadas', r.evolutions],
        ['Turnos utilizados', `${pad(r.turns)} / ${CONFIG.maxTurns}`],
        ['DNA restante', r.dna],
        ['Pesquisa Global', `${r.research}%`],
        ['Infectados', formatPeople(r.infected ?? 0)],
        ['Mortos', formatPeople(r.dead ?? 0)],
      ]
    : [
        ['Cidades alcançadas', r.cities],
        ['Regiões alcançadas', `${r.regions}/4`],
        ['Pesquisa Global', `${r.research}%`],
        ['Turnos sobrevividos', `${pad(r.turns)} / ${CONFIG.maxTurns}`],
        ['Infectados', formatPeople(r.infected ?? 0)],
        ['Mortos', formatPeople(r.dead ?? 0)],
      ]
  const breakdown = victory
    ? `<ul class="end-breakdown">
        <li><span>Pontuação da partida</span><strong>${r.baseScore.toLocaleString('pt-BR')}</strong></li>
        <li><span>DNA restante (${r.dna} × ${CONFIG.dnaScore})</span><strong>+${r.dnaBonus.toLocaleString('pt-BR')}</strong></li>
        <li><span>Bônus de eficiência</span><strong>+${r.efficiency.toLocaleString('pt-BR')}</strong></li>
      </ul>`
    : ''
  const text = victory
    ? 'Você completou todos os objetivos antes da conclusão da pesquisa.'
    : r.reason === 'time'
      ? 'Os 15 turnos terminaram e a comunidade internacional finalizou a cura.'
      : 'A Pesquisa Global chegou a 100% antes de você completar os objetivos.'

  $('#end-dialog').dataset.result = r.type
  $('#end-body').innerHTML = `
    <div class="end-hero">
      <span class="end-emblem">${icon(victory ? 'trophy' : 'shield', 34)}</span>
      <p class="eyebrow">${victory ? 'Vitória' : 'Fim de Jogo'}</p>
      <h2 class="end-title" id="end-title">${victory ? 'EXPANSÃO CONCLUÍDA' : 'CURA CONCLUÍDA'}</h2>
      <p class="end-text">${text}</p>
    </div>
    <div class="end-score"><span>Pontuação final</span><strong id="end-score">0</strong></div>
    <dl class="end-stats">${stats.map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('')}</dl>
    ${breakdown}
    <div class="end-actions">
      <button class="btn btn-primary btn-lg" data-action="new-game">${icon('refresh', 18)} ${victory ? 'Jogar Novamente' : 'Tentar Novamente'}</button>
      <button class="btn btn-ghost btn-lg" data-action="main-menu">${icon('home', 18)} Menu Principal</button>
    </div>`
  animateNumber($('#end-score'), 0, r.finalScore, 1400)
}

// ---------- Sequência de fim de turno ----------
const STEPS = ['Encerrado', 'Pesquisa', 'Evento', 'Próximo turno']

export function showTurnStage({ step, kicker, title, sub = '', card = null }) {
  const overlay = $('#turn-overlay')
  overlay.hidden = false
  overlay.dataset.step = step
  $('#to-steps').innerHTML = STEPS.map(
    (s, i) => `<li class="${i < step ? 'is-done' : ''}${i === step ? ' is-current' : ''}">${s}</li>`,
  ).join('')
  $('#to-kicker').textContent = kicker
  const titleEl = $('#to-title')
  titleEl.textContent = title
  bump(titleEl, 'is-entering')
  $('#to-sub').innerHTML = sub
  const cardEl = $('#to-card')
  if (card) {
    cardEl.hidden = false
    cardEl.className = `to-card tone-${card.tone}`
    cardEl.innerHTML = `<span class="to-card-icon">${icon(card.icon, 26)}</span>
      <div><p class="eyebrow">${card.tone === 'good' ? 'Favorável' : card.tone === 'bad' ? 'Desfavorável' : 'Neutro'}</p>
      <h3>${card.name}</h3><p>${card.desc}</p><p class="to-card-detail">${card.detail}</p></div>`
    bump(cardEl, 'is-entering')
  } else {
    cardEl.hidden = true
  }
}

export function hideTurnOverlay() {
  $('#turn-overlay').hidden = true
}

// ---------- Toasts ----------
export function toast(title, { tone = 'info', sub = '', iconName = null, duration = 2600, big = false } = {}) {
  const container = $('#toasts')
  const el = document.createElement('div')
  el.className = `toast tone-${tone}${big ? ' is-big' : ''}`
  el.setAttribute('role', 'status')
  const ic = iconName || { good: 'check', bad: 'alert', info: 'globe', warn: 'alert' }[tone] || 'globe'
  el.innerHTML = `<span class="toast-icon">${icon(ic, big ? 20 : 16)}</span><div><strong>${title}</strong>${sub ? `<span>${sub}</span>` : ''}</div>`
  container.appendChild(el)
  while (container.children.length > 4) container.firstElementChild.remove()
  setTimeout(() => {
    el.classList.add('is-leaving')
    setTimeout(() => el.remove(), 350)
  }, duration)
}

// ---------- Tela de regras ----------
const RULES = [
  {
    title: 'Objetivo',
    body: `<p>Você controla a expansão de uma doença <strong>totalmente fictícia</strong> em um mundo inventado. Comece em uma cidade e use as rotas para alcançar outras.</p>
      <p>Uma organização internacional corre para desenvolver a cura. <strong>Complete os 3 objetivos principais antes que a Pesquisa Global chegue a 100%.</strong></p>
      <div class="rule-visual rule-states">
        ${['healthy', 'exposed', 'infected', 'contained'].map(stateChip).join('')}
      </div>
      <p class="subtle">Cada cidade mostra seu estado com cor <em>e</em> texto: Saudável, Exposta, Infectada ou Contida.</p>`,
  },
  {
    title: 'Turnos',
    body: `<p>A partida tem no máximo <strong>15 turnos</strong>. Em cada turno você tem <strong>3 ações</strong>.</p>
      <div class="rule-visual rule-turn"><span class="rule-turn-label">TURNO 04 / 15</span><span class="rule-pips"><i class="on"></i><i class="on"></i><i></i></span></div>
      <ul class="rule-list">
        <li><strong>Expandir</strong> — alcança uma cidade vizinha pagando o custo da rota.</li>
        <li><strong>Evoluir</strong> — compra uma melhoria no Laboratório.</li>
        <li><strong>Habilidade</strong> — rompe contenções ou interfere na pesquisa.</li>
        <li><strong>Recursos</strong> — coleta DNA (mais DNA com cidades acima de 60% de infecção).</li>
        <li><strong>Encerrar Turno</strong> — não gasta ação. Dispara a pesquisa e um evento global.</li>
      </ul>`,
  },
  {
    title: 'Rotas',
    body: `<p>Você só pode se expandir de uma cidade <strong>infectada</strong> para uma cidade <strong>saudável</strong> conectada por rota.</p>
      <ul class="legend legend-routes rule-visual">
        <li><span class="rp-line type-normal"></span><span><strong>Normal</strong> · 1 DNA</span></li>
        <li><span class="rp-line type-long"></span><span><strong>Longa</strong> · 2 DNA</span></li>
        <li><span class="rp-line type-hard"></span><span><strong>Difícil</strong> · 3 DNA</span></li>
      </ul>
      <p>Clique em uma rota ou cidade, confira o custo e confirme. Uma energia percorre o caminho e a cidade muda de estado.</p>`,
  },
  {
    title: 'DNA',
    body: `<p>Os <strong>Pontos de DNA</strong> são o seu recurso principal. Você começa com ${CONFIG.startDna}.</p>
      <div class="rule-visual rule-chips"><span class="chip-pos">+1 DNA por nova cidade</span><span class="chip-pos">+2 DNA por nova região</span><span class="chip-pos">Coletar recursos</span><span class="chip-pos">Renda passiva por turno</span></div>
      <div class="rule-visual rule-chips"><span class="chip-neg">Rotas</span><span class="chip-neg">Evoluções</span><span class="chip-neg">Habilidades</span></div>
      <p class="subtle">Guardar DNA também vale: cada DNA restante no final vale ${CONFIG.dnaScore} pontos.</p>`,
  },
  {
    title: 'Evoluções',
    body: `<p>No <strong>Laboratório de Evolução</strong> você compra melhorias abstratas em uma árvore de 3 camadas.</p>
      <ul class="rule-list">${EVOLUTIONS.map((e) => `<li><strong>${e.name}</strong> — ${e.desc}</li>`).join('')}</ul>
      <p class="subtle">A Camada II exige 1 evolução desbloqueada e a Camada III exige 2.</p>`,
  },
  {
    title: 'Pesquisa Global',
    body: `<p>A cada fim de turno a pesquisa avança. Ela cresce mais rápido quanto maior for a sua expansão, e cada nova cidade também a aumenta.</p>
      <div class="rule-visual rule-research"><span style="--w:39%" data-l="stable">Estável</span><span style="--w:30%" data-l="warn">Atenção</span><span style="--w:20%" data-l="alert">Alerta</span><span style="--w:11%" data-l="critical">Crítico</span></div>
      <p>Com a pesquisa acima de 20%, cidades com menos de 80% de infecção podem ser <strong>contidas</strong>. Cidades contidas não contam para o objetivo e não servem de origem.</p>`,
  },
  {
    title: 'Objetivos',
    body: `<p><strong>Principais</strong> (todos são necessários para vencer):</p>
      <ul class="rule-list">${OBJECTIVES.filter((o) => o.type === 'main').map((o) => `<li>${o.label}</li>`).join('')}</ul>
      <p><strong>Bônus</strong> (+${CONFIG.objectiveScore} pontos cada):</p>
      <ul class="rule-list">${OBJECTIVES.filter((o) => o.type === 'bonus').map((o) => `<li>${o.label}</li>`).join('')}</ul>`,
  },
  {
    title: 'Vitória',
    body: `<p>Você vence assim que concluir os 3 objetivos principais. A pontuação final soma:</p>
      <ul class="rule-list">
        <li>+${CONFIG.cityScore} por cidade alcançada</li>
        <li>+${CONFIG.regionScore} por nova região</li>
        <li>+${CONFIG.objectiveScore} por objetivo concluído</li>
        <li>+${CONFIG.dnaScore} por DNA restante</li>
        <li>+${CONFIG.efficiencyPerTurn} por turno não utilizado (bônus de eficiência)</li>
      </ul>`,
  },
  {
    title: 'Derrota',
    body: `<p>Você perde se a <strong>Pesquisa Global chegar a 100%</strong> ou se os <strong>15 turnos</strong> terminarem antes dos objetivos.</p>
      <p>Para segurar a pesquisa: use a <strong>Expansão Silenciosa</strong>, a habilidade <strong>Interferência de Dados</strong> e não desperdice turnos.</p>
      <p class="subtle">Eventos globais podem ajudar ou atrapalhar. Leia o cartão de evento a cada turno!</p>`,
  },
]

export function renderRules(index) {
  $('#rules-tabs').innerHTML = RULES.map(
    (r, i) => `<li><button class="rules-tab${i === index ? ' is-active' : ''}" data-action="rules-tab" data-index="${i}" aria-current="${i === index ? 'step' : 'false'}"><span>${i + 1}</span>${r.title}</button></li>`,
  ).join('')
  $('#rules-content').innerHTML = `<p class="eyebrow">Seção ${i18nCount(index + 1)} de ${RULES.length}</p><h3 class="rules-title">${RULES[index].title}</h3>${RULES[index].body}`
  $('#rules-prev').disabled = index === 0
  $('#rules-next').innerHTML = index === RULES.length - 1 ? `Entendi ${icon('check', 16)}` : `Próximo ${icon('arrowRight', 16)}`
}

const i18nCount = (n) => pad(n)
export const RULES_COUNT = RULES.length
