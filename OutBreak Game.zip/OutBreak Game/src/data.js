// =============================================================
// DADOS ESTÁTICOS DO JOGO
// Regiões, cidades, rotas, evoluções, eventos e objetivos.
// Nada aqui muda durante a partida: o estado fica em state.js.
// =============================================================

export const CONFIG = {
  maxTurns: 15,
  actionsPerTurn: 3,
  startDna: 8,
  startInfection: 35, // infecção inicial (%) de uma cidade recém-alcançada
  originInfection: 40,
  cityScore: 100,
  regionScore: 25,
  objectiveScore: 50,
  dnaScore: 10, // pontos por DNA restante no fim
  efficiencyPerTurn: 30, // bônus por turno não utilizado
  researchPerCity: 2, // % de pesquisa gerada por nova cidade
  collectBase: 2,
  breachCost: 2,
  interfereCost: 3,
  interfereAmount: 5,
  // Letalidade: fração dos infectados que morre a cada fim de turno
  baseLethality: 0.01,
  lethalityPerTurn: 0.006,
  lethalityHighInfection: 0.03, // extra quando a infecção da cidade passa de 80%
  maxLethality: 0.15,
  containedLethalityFactor: 0.4,
}

// Cada região tem "blobs" (elipses: cx, cy, rx, ry) usados para desenhar
// o continente fictício em pontos no mapa.
export const REGIONS = [
  {
    id: 'norte',
    name: 'Região Boreal',
    color: '#8ab4ff',
    label: [515, 24],
    blobs: [
      [300, 115, 125, 58],
      [515, 88, 135, 52],
      [725, 122, 120, 56],
      [175, 150, 48, 30],
      [410, 70, 60, 30],
      [640, 85, 55, 28],
      [860, 160, 55, 34],
      [600, 42, 40, 16],
    ],
  },
  {
    id: 'central',
    name: 'Núcleo Central',
    color: '#3ee6c4',
    label: [705, 196],
    blobs: [
      [505, 285, 175, 92],
      [600, 360, 95, 58],
      [395, 320, 62, 44],
      [690, 245, 55, 48],
      [520, 198, 80, 32],
      [470, 360, 50, 30],
    ],
  },
  {
    id: 'oeste',
    name: 'Costa Ocidental',
    color: '#c9a7ff',
    label: [110, 140],
    blobs: [
      [170, 315, 105, 150],
      [245, 445, 72, 52],
      [115, 235, 60, 70],
      [95, 390, 40, 48],
      [215, 225, 48, 40],
      [300, 420, 34, 30],
    ],
  },
  {
    id: 'sul',
    name: 'Arquipélago Austral',
    color: '#f5b84a',
    label: [610, 578],
    blobs: [
      [430, 492, 82, 44],
      [612, 508, 102, 44],
      [792, 432, 92, 58],
      [862, 330, 62, 72],
      [520, 528, 24, 14],
      [705, 482, 22, 15],
      [915, 255, 28, 22],
      [345, 538, 26, 13],
      [958, 385, 18, 26],
    ],
  },
]

// population em milhões. labelBelow: posiciona o nome abaixo do ponto.
export const CITIES = [
  { id: 'arcton', name: 'Arcton', region: 'norte', x: 300, y: 112, population: 3.4 },
  { id: 'frostfall', name: 'Frostfall', region: 'norte', x: 515, y: 82, population: 1.9 },
  { id: 'orion', name: 'Orion', region: 'norte', x: 728, y: 120, population: 2.7 },
  { id: 'novacity', name: 'Nova City', region: 'central', x: 500, y: 262, population: 8.2 },
  { id: 'meridian', name: 'Meridian', region: 'central', x: 392, y: 302, population: 5.1 },
  { id: 'solaris', name: 'Solaris', region: 'central', x: 630, y: 238, population: 6.4 },
  { id: 'lumina', name: 'Lumina', region: 'central', x: 585, y: 362, population: 4.3, labelBelow: true },
  { id: 'newavalon', name: 'New Avalon', region: 'oeste', x: 162, y: 212, population: 7.0 },
  { id: 'westhaven', name: 'Westhaven', region: 'oeste', x: 105, y: 345, population: 2.2, labelBelow: true },
  { id: 'redmont', name: 'Redmont', region: 'oeste', x: 232, y: 318, population: 3.8 },
  { id: 'valora', name: 'Valora', region: 'oeste', x: 245, y: 445, population: 4.6, labelBelow: true },
  { id: 'portazure', name: 'Port Azure', region: 'sul', x: 430, y: 490, population: 5.5, labelBelow: true },
  { id: 'eldoria', name: 'Eldoria', region: 'sul', x: 612, y: 505, population: 3.1, labelBelow: true },
  { id: 'kairox', name: 'Kairox', region: 'sul', x: 790, y: 438, population: 2.9, labelBelow: true },
  { id: 'santara', name: 'Santara', region: 'sul', x: 862, y: 318, population: 4.0 },
]

// [cidadeA, cidadeB, custo] — custo 1 = Normal, 2 = Longa, 3 = Difícil
const ROUTE_DEFS = [
  ['novacity', 'meridian', 1],
  ['novacity', 'solaris', 1],
  ['novacity', 'lumina', 1],
  ['meridian', 'lumina', 1],
  ['solaris', 'lumina', 1],
  ['novacity', 'frostfall', 2],
  ['meridian', 'arcton', 2],
  ['solaris', 'orion', 2],
  ['arcton', 'frostfall', 1],
  ['frostfall', 'orion', 1],
  ['meridian', 'redmont', 2],
  ['arcton', 'newavalon', 3],
  ['newavalon', 'redmont', 1],
  ['newavalon', 'westhaven', 1],
  ['westhaven', 'redmont', 1],
  ['redmont', 'valora', 1],
  ['westhaven', 'valora', 1],
  ['valora', 'portazure', 2],
  ['lumina', 'portazure', 2],
  ['portazure', 'eldoria', 1],
  ['eldoria', 'kairox', 1],
  ['lumina', 'eldoria', 3],
  ['kairox', 'santara', 1],
  ['solaris', 'santara', 2],
  ['orion', 'santara', 3],
]

export const ROUTE_TYPES = {
  1: { id: 'normal', label: 'Normal' },
  2: { id: 'long', label: 'Longa' },
  3: { id: 'hard', label: 'Difícil' },
}

export const ROUTES = ROUTE_DEFS.map(([a, b, cost], index) => ({
  id: `${a}-${b}`,
  a,
  b,
  cost,
  index,
  type: ROUTE_TYPES[cost].id,
  typeLabel: ROUTE_TYPES[cost].label,
}))

export const EVOLUTIONS = [
  {
    id: 'fast',
    name: 'Transmissão Rápida',
    icon: 'zap',
    tier: 1,
    baseCost: 4,
    maxLevel: 2,
    desc: 'Melhora a eficiência das expansões.',
    effect: (lvl) =>
      `Novas cidades começam com +${15 * lvl}% de infecção e a infecção cresce +${8 * lvl}% por turno.`,
  },
  {
    id: 'mutation',
    name: 'Mutação',
    icon: 'shuffle',
    tier: 1,
    baseCost: 3,
    maxLevel: 3,
    desc: 'Concede um bônus temporário aleatório.',
    effect: () => 'Bônus sorteado: +2 ações, +5 DNA, expansão gratuita ou Pesquisa Global −5%.',
  },
  {
    id: 'env',
    name: 'Adaptação Ambiental',
    icon: 'mountain',
    tier: 2,
    baseCost: 4,
    maxLevel: 2,
    desc: 'Reduz penalidades de determinadas regiões.',
    effect: (lvl) =>
      lvl === 1
        ? 'Rotas difíceis custam −1 DNA e bloqueios regionais são ignorados.'
        : 'Rotas longas também passam a custar −1 DNA.',
  },
  {
    id: 'silent',
    name: 'Expansão Silenciosa',
    icon: 'eyeOff',
    tier: 2,
    baseCost: 5,
    maxLevel: 2,
    desc: 'Reduz o aumento de Pesquisa Global causado por novas cidades.',
    effect: (lvl) =>
      `Novas cidades geram −${lvl}% de pesquisa e a chance de contenção cai ${15 * lvl}%.`,
  },
  {
    id: 'global',
    name: 'Adaptação Global',
    icon: 'globe',
    tier: 3,
    baseCost: 6,
    maxLevel: 2,
    desc: 'Melhora a eficiência de expansão em diferentes regiões.',
    effect: (lvl) => `Cada nova cidade rende +${lvl} DNA extra e cada nova região, +${lvl} DNA extra.`,
  },
]

// Evoluções de nível 2 exigem 1 desbloqueada; nível 3 exige 2.
export const TIER_REQUIREMENTS = { 1: 0, 2: 1, 3: 2 }

export const EVENTS = [
  { id: 'breakthrough', name: 'Avanço Científico', tone: 'bad', icon: 'activity', weight: 2, desc: 'Laboratórios internacionais compartilham dados.' },
  { id: 'travel', name: 'Restrições de Viagem', tone: 'bad', icon: 'alert', weight: 2, desc: 'Fronteiras ficam mais rígidas por um turno.' },
  { id: 'breach', name: 'Falha de Contenção', tone: 'good', icon: 'shield', weight: 1.5, desc: 'Uma barreira de contenção apresentou falhas.' },
  { id: 'resources', name: 'Descoberta de Recursos', tone: 'good', icon: 'dna', weight: 2, desc: 'Você encontrou recursos inesperados.' },
  { id: 'emergency', name: 'Resposta de Emergência', tone: 'bad', icon: 'alert', weight: 2, desc: 'Governos ativam protocolos de emergência.' },
  { id: 'blockade', name: 'Bloqueio Regional', tone: 'bad', icon: 'lock', weight: 1.5, desc: 'Uma região reforça o controle de acesso.' },
  { id: 'momentum', name: 'Fluxo Intenso', tone: 'good', icon: 'route', weight: 1.5, desc: 'O trânsito global está acima do normal.' },
  { id: 'calm', name: 'Silêncio na Rede', tone: 'neutral', icon: 'globe', weight: 1, desc: 'Nenhuma movimentação relevante foi detectada.' },
]

// evaluateAtEnd: só é verificado no momento da vitória.
export const OBJECTIVES = [
  { id: 'cities', type: 'main', label: 'Alcançar 10 cidades infectadas', target: 10 },
  { id: 'regions', type: 'main', label: 'Alcançar 3 regiões', target: 3 },
  { id: 'evolutions', type: 'main', label: 'Desbloquear 3 evoluções', target: 3 },
  { id: 'early', type: 'bonus', label: 'Vencer antes do turno 12', evaluateAtEnd: true },
  { id: 'bank', type: 'bonus', label: 'Terminar com pelo menos 15 DNA', target: 15, evaluateAtEnd: true },
  { id: 'allRegions', type: 'bonus', label: 'Alcançar todas as regiões', target: 4 },
]

// ---- Índices para acesso rápido ----
export const CITY_BY_ID = Object.fromEntries(CITIES.map((c) => [c.id, c]))
export const REGION_BY_ID = Object.fromEntries(REGIONS.map((r) => [r.id, r]))
export const ROUTE_BY_ID = Object.fromEntries(ROUTES.map((r) => [r.id, r]))
export const EVO_BY_ID = Object.fromEntries(EVOLUTIONS.map((e) => [e.id, e]))
export const ROUTES_BY_CITY = Object.fromEntries(
  CITIES.map((c) => [c.id, ROUTES.filter((r) => r.a === c.id || r.b === c.id)]),
)
