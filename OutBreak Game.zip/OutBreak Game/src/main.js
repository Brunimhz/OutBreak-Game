// =============================================================
// CONTROLADOR PRINCIPAL
// Liga cliques/teclas às regras, e regras às animações.
// =============================================================
import './style.css'
import { icon, hydrateIcons } from './icons.js'
import { createInitialState } from './state.js'
import * as rules from './rules.js'
import { CITY_BY_ID, REGION_BY_ID, ROUTE_BY_ID } from './data.js'
import {
  animateTravel,
  buildMap,
  flashRoute,
  getCityScreenPoint,
  pingCity,
  scrollToCity,
  startMenuDemo,
  startTraffic,
  stopMenuDemo,
  updateMap,
} from './map.js'
import * as ui from './ui.js'
import * as fx from './fx.js'
import { setSoundEnabled, sfx } from './audio.js'

const $ = (sel) => document.querySelector(sel)
const pad = (n) => String(n).padStart(2, '0')

let state = createInitialState()
let busy = false // bloqueia cliques durante animações
let rulesIndex = 0

// ---------- Configurações (preferências salvas no navegador) ----------
const SETTINGS_KEY = 'global-outbreak-settings'
const settings = {
  sound: false,
  reduced: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  contrast: false,
}
try {
  Object.assign(settings, JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}'))
} catch {
  /* preferências inválidas: mantém o padrão */
}

function applySettings() {
  document.body.classList.toggle('reduced-motion', settings.reduced)
  document.body.classList.toggle('high-contrast', settings.contrast)
  fx.motion.reduced = settings.reduced
  setSoundEnabled(settings.sound)
  document.querySelectorAll('[data-setting]').forEach((el) => {
    el.setAttribute('aria-checked', String(!!settings[el.dataset.setting]))
  })
  const soundBtn = $('#btn-sound')
  soundBtn.innerHTML = icon(settings.sound ? 'volume' : 'mute', 20)
  soundBtn.setAttribute('aria-pressed', String(settings.sound))
  soundBtn.setAttribute('aria-label', settings.sound ? 'Desativar som' : 'Ativar som')
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings))
  } catch {
    /* armazenamento indisponível */
  }
}

// ---------- Renderização ----------
function render() {
  updateMap(state)
  ui.renderWorld(state)
  ui.renderHUD(state)
  ui.renderObjectives(state)
  ui.renderEvent(state)
  ui.renderLog(state)
  ui.renderPanel(state)
  ui.renderActions(state)
  ui.renderHint(state)
}

// ---------- Utilidades ----------
let skipWait = null
function wait(ms) {
  const duration = settings.reduced ? ms * 0.55 : ms
  return new Promise((resolve) => {
    const done = () => {
      clearTimeout(timer)
      skipWait = null
      resolve()
    }
    const timer = setTimeout(done, duration)
    skipWait = done
  })
}

function deny(message, el) {
  sfx.error()
  ui.toast(message, { tone: 'bad' })
  if (el) fx.shake(el)
}

function closeAllDialogs() {
  document.querySelectorAll('dialog[open]').forEach((d) => d.close())
}

function openDialog(id) {
  const dialog = document.getElementById(id)
  if (!dialog.open) dialog.showModal()
}

const statEl = (key) => $(key === 'dna' ? '#stat-dna' : '#stat-score')

/** Executa os efeitos visuais/sonoros de uma ação na ordem certa. */
async function playEffects(effects) {
  busy = true
  for (const e of effects.filter((x) => x.type === 'spend')) {
    fx.floatText(`−${e.amount} DNA`, fx.centerOf(statEl('dna')), 'neg')
  }
  const travel = effects.find((e) => e.type === 'travel')
  if (travel) {
    sfx.travel()
    await animateTravel(travel.routeId, travel.from)
  }
  render()

  let objectiveDelay = 0
  for (const e of effects) {
    switch (e.type) {
      case 'city':
        pingCity(e.cityId, 'infect')
        break
      case 'score':
        fx.floatText(`+${e.amount}`, getCityScreenPoint(e.cityId), 'score')
        break
      case 'dna': {
        const from = e.cityId ? getCityScreenPoint(e.cityId) : fx.centerOf($('#research'))
        fx.particleBurst(from, statEl('dna'), Math.min(10, 3 + e.amount), () => {
          fx.bump(statEl('dna'))
          fx.floatText(`+${e.amount} DNA`, fx.centerOf(statEl('dna')), 'dna')
        })
        sfx.dna()
        break
      }
      case 'region':
        ui.toast(`Nova região: ${REGION_BY_ID[e.regionId].name}`, { tone: 'good', sub: `+${e.amount} pontos · +DNA bônus`, iconName: 'globe' })
        break
      case 'research':
        fx.floatText(`${e.amount > 0 ? '+' : ''}${e.amount}% pesquisa`, fx.centerOf($('#research-fill').parentElement), e.amount > 0 ? 'warn' : 'pos')
        break
      case 'objective':
        objectiveDelay += 350
        setTimeout(() => {
          sfx.objective()
          ui.toast('OBJETIVO CONCLUÍDO', { tone: 'good', sub: `${e.label} · +${e.amount} pontos`, iconName: 'check', big: true, duration: 3200 })
          ui.flashObjective(e.id)
        }, objectiveDelay)
        break
      case 'mutation':
        ui.toast('Mutação ativada', { tone: 'good', sub: e.label, iconName: 'shuffle', duration: 3200 })
        break
      case 'breach':
        pingCity(e.cityId, 'breach')
        break
      case 'victory':
        setTimeout(showEnd, objectiveDelay + 1200)
        break
    }
  }
  busy = false
}

function showEnd() {
  closeAllDialogs()
  ui.hideTurnOverlay()
  ui.renderEnd(state)
  openDialog('end-dialog')
  hydrateIcons($('#end-dialog'))
  if (state.result.type === 'victory') {
    sfx.victory()
    fx.celebrate()
  } else {
    sfx.defeat()
    fx.bump(document.body, 'is-defeat-flash')
  }
}

// ---------- Fluxo de telas ----------
function startGame() {
  closeAllDialogs()
  ui.hideTurnOverlay()
  stopMenuDemo()
  state = createInitialState()
  busy = false
  ui.resetShownValues()
  document.body.dataset.screen = 'game'
  document.body.classList.remove('objectives-open')
  render()
  sfx.confirm()
  ui.toast('Escolha a cidade de origem', { tone: 'info', sub: 'Clique em qualquer cidade do mapa.', iconName: 'crosshair', duration: 3500 })
}

function goToMenu() {
  closeAllDialogs()
  ui.hideTurnOverlay()
  state = createInitialState()
  busy = false
  document.body.dataset.screen = 'menu'
  document.body.classList.remove('objectives-open')
  replayIntro()
  render()
  startMenuDemo()
}

function replayIntro() {
  document.body.classList.remove('intro')
  void document.body.offsetWidth
  document.body.classList.add('intro')
}

// ---------- Ações de jogo ----------
function selectCity(cityId) {
  if (document.body.dataset.screen !== 'game' || busy) return
  if (state.phase === 'setup') {
    state.selectedCity = cityId
    sfx.select()
    pingCity(cityId, 'select')
    render()
    return
  }
  if (state.phase !== 'playing') return
  state.selectedCity = cityId
  const options = rules.getAvailableExpansions(state)
  const toCity = options.filter((o) => o.to === cityId)
  if (toCity.length) {
    // Atalho: clicar numa cidade alcançável já seleciona a rota mais barata
    const best = toCity[0]
    state.selectedRoute = { routeId: best.routeId, from: best.from, to: best.to }
  } else if (state.selectedRoute && state.selectedRoute.from !== cityId && state.selectedRoute.to !== cityId) {
    state.selectedRoute = null
  }
  sfx.select()
  pingCity(cityId, 'select')
  render()
  scrollToCity(cityId, $('#map-stage'))
}

function selectRoute(routeId) {
  if (busy) return
  if (state.phase === 'setup') return deny('Escolha primeiro a cidade de origem.')
  if (state.phase !== 'playing') return
  const option = rules.getAvailableExpansions(state).find((o) => o.routeId === routeId)
  if (!option) {
    flashRoute(routeId)
    return deny(rules.getRouteBlockReason(state, ROUTE_BY_ID[routeId]))
  }
  state.selectedRoute = { routeId, from: option.from, to: option.to }
  if (!state.expandMode && state.selectedCity !== option.from && state.selectedCity !== option.to) {
    state.selectedCity = option.from
  }
  sfx.select()
  render()
}

async function confirmExpand(btn) {
  if (busy || !state.selectedRoute) return
  const { routeId, to } = state.selectedRoute
  const result = rules.expand(state, routeId)
  if (!result.ok) return deny(result.message, btn)
  sfx.confirm()
  state.selectedRoute = null
  state.selectedCity = to
  if (state.actionsRemaining <= 0 || rules.getAvailableExpansions(state).length === 0) state.expandMode = false
  await playEffects(result.effects)
}

function startOutbreak() {
  if (state.phase !== 'setup' || !state.selectedCity) return
  const result = rules.startOutbreak(state, state.selectedCity)
  if (!result.ok) return deny(result.message)
  sfx.confirm()
  ui.toast(`Surto iniciado em ${CITY_BY_ID[state.originCity].name}`, { tone: 'good', sub: 'Você tem 3 ações por turno. Comece expandindo!', iconName: 'crosshair' })
  playEffects(result.effects)
}

function toggleExpand(btn) {
  if (busy) return
  if (state.phase === 'setup') return deny('Escolha primeiro a cidade de origem.', btn)
  if (state.phase !== 'playing') return
  if (!state.expandMode && state.actionsRemaining <= 0) return deny('Sem ações restantes. Encerre o turno.', btn)
  state.expandMode = !state.expandMode
  if (!state.expandMode) state.selectedRoute = null
  else if (rules.getAvailableExpansions(state).length === 0)
    ui.toast('Nenhuma rota disponível', { tone: 'warn', sub: 'Rompa uma contenção para liberar novas rotas.' })
  sfx.click()
  render()
}

function openLab(btn) {
  if (state.phase === 'setup') return deny('Escolha primeiro a cidade de origem.', btn)
  if (state.phase !== 'playing' || busy) return
  ui.renderLab(state)
  openDialog('dlg-lab')
  sfx.click()
}

async function doEvolve(btn) {
  if (busy) return
  const id = btn.dataset.evo
  const result = rules.evolve(state, id)
  if (!result.ok) return deny(result.message, btn.closest('.evo-node') || btn)
  sfx.unlock()
  ui.renderLab(state, id)
  await playEffects(result.effects)
}

function openAbility(btn) {
  if (state.phase === 'setup') return deny('Escolha primeiro a cidade de origem.', btn)
  if (state.phase !== 'playing' || busy) return
  ui.renderAbility(state)
  openDialog('dlg-ability')
  sfx.click()
}

async function doBreach(btn) {
  if (busy) return
  const result = rules.breachContainment(state, btn.dataset.city)
  if (!result.ok) return deny(result.message, btn)
  $('#dlg-ability').close()
  sfx.confirm()
  ui.toast(`Contenção rompida em ${CITY_BY_ID[btn.dataset.city].name}`, { tone: 'good', iconName: 'shield' })
  await playEffects(result.effects)
}

async function doInterfere(btn) {
  if (busy) return
  const result = rules.interfereResearch(state)
  if (!result.ok) return deny(result.message, btn)
  $('#dlg-ability').close()
  sfx.confirm()
  ui.toast('Interferência de Dados', { tone: 'good', sub: 'Pesquisa Global −5%', iconName: 'activity' })
  await playEffects(result.effects)
}

async function doCollect(btn) {
  if (busy) return
  if (state.phase === 'setup') return deny('Escolha primeiro a cidade de origem.', btn)
  const result = rules.collectResources(state)
  if (!result.ok) return deny(result.message, btn)
  sfx.confirm()
  await playEffects(result.effects)
}

async function endTurn(btn) {
  if (busy) return
  if (state.phase === 'setup') return deny('Escolha primeiro a cidade de origem.', btn)
  if (state.phase !== 'playing') return
  busy = true
  closeAllDialogs()
  document.body.classList.remove('objectives-open')
  sfx.turn()

  const unused = state.actionsRemaining
  ui.showTurnStage({
    step: 0,
    kicker: `Turno ${pad(state.currentTurn)}`,
    title: 'TURNO ENCERRADO',
    sub: unused > 0 ? `${unused} ${unused === 1 ? 'ação não utilizada' : 'ações não utilizadas'}.` : 'Todas as ações foram usadas.',
  })
  await wait(900)

  const report = rules.resolveResearchPhase(state)
  render()
  const containedText = report.contained
    ? `<br><span class="sub-bad">${CITY_BY_ID[report.contained].name} foi contida pela resposta global.</span>`
    : ''
  ui.showTurnStage({
    step: 1,
    kicker: 'Resposta internacional',
    title: 'FASE DE PESQUISA',
    sub: `Pesquisa Global <strong class="sub-warn">+${report.gain}%</strong> · agora em ${state.research}%<br>Infecção nas cidades ativas +${report.growth}%${
      report.newDeaths > 0
        ? `<br><span class="sub-dead">+${report.newDeaths.toLocaleString('pt-BR')} mortos</span> · ${report.world.infected.toLocaleString('pt-BR')} infectados`
        : ''
    }${containedText}`,
  })
  if (report.contained) pingCity(report.contained, 'contain')
  await wait(1700)
  if (state.phase === 'defeat') return finishTurnSequence()

  const { event, effects } = rules.resolveEventPhase(state)
  render()
  sfx.event()
  ui.showTurnStage({ step: 2, kicker: 'Evento global', title: event.name.toUpperCase(), card: event })
  await wait(2800)
  if (state.phase === 'defeat' || state.phase === 'victory') return finishTurnSequence(effects)

  const next = rules.startNextTurn(state)
  if (state.phase === 'defeat') return finishTurnSequence()
  sfx.turn()
  render()
  ui.showTurnStage({
    step: 3,
    kicker: 'Novo ciclo',
    title: `TURNO ${pad(state.currentTurn)} / 15`,
    sub: `${state.actionsRemaining} ações disponíveis${next.passive ? ` · Renda passiva <strong class="sub-good">+${next.passive} DNA</strong>` : ''}`,
  })
  await wait(1100)
  ui.hideTurnOverlay()
  busy = false
  render()
  if (next.passive) fx.floatText(`+${next.passive} DNA`, fx.centerOf(statEl('dna')), 'dna')
}

function finishTurnSequence(effects = []) {
  ui.hideTurnOverlay()
  busy = false
  render()
  if (state.phase === 'victory') playEffects(effects)
  else if (state.phase === 'defeat') setTimeout(showEnd, 300)
}

// ---------- Mapa de ações (data-action) ----------
const ACTIONS = {
  'start-game': startGame,
  'open-rules': () => {
    rulesIndex = 0
    ui.renderRules(rulesIndex)
    openDialog('dlg-rules')
  },
  'rules-tab': (el) => {
    rulesIndex = Number(el.dataset.index)
    ui.renderRules(rulesIndex)
  },
  'rules-prev': () => {
    rulesIndex = Math.max(0, rulesIndex - 1)
    ui.renderRules(rulesIndex)
  },
  'rules-next': () => {
    if (rulesIndex >= ui.RULES_COUNT - 1) return $('#dlg-rules').close()
    rulesIndex += 1
    ui.renderRules(rulesIndex)
  },
  'open-settings': () => openDialog('dlg-settings'),
  'toggle-setting': (el) => {
    const key = el.dataset.setting
    settings[key] = !settings[key]
    applySettings()
    sfx.click()
  },
  'toggle-sound': () => {
    settings.sound = !settings.sound
    applySettings()
    sfx.select()
  },
  'close-dialog': (el) => el.closest('dialog')?.close(),
  pause: () => openDialog('dlg-pause'),
  'new-game': startGame,
  'main-menu': goToMenu,
  'toggle-objectives': () => document.body.classList.toggle('objectives-open'),
  'select-city': (el) => selectCity(el.dataset.city),
  'select-route': (el) => selectRoute(el.dataset.route),
  deselect: () => {
    state.selectedCity = null
    state.selectedRoute = null
    state.expandMode = false
    render()
  },
  'cancel-route': () => {
    state.selectedRoute = null
    sfx.click()
    render()
  },
  'start-outbreak': startOutbreak,
  'confirm-expand': confirmExpand,
  'toggle-expand': toggleExpand,
  'open-lab': openLab,
  evolve: doEvolve,
  'open-ability': openAbility,
  breach: doBreach,
  interfere: doInterfere,
  collect: doCollect,
  'end-turn': endTurn,
  'skip-stage': () => skipWait?.(),
}

document.addEventListener('click', (event) => {
  const target = event.target.closest('[data-action]')
  if (!target) return
  const handler = ACTIONS[target.dataset.action]
  if (handler) handler(target, event)
})

// Clicar no "oceano" limpa a seleção
$('#map-stage').addEventListener('click', (event) => {
  if (event.target.closest('[data-action]') || state.phase === 'transition') return
  if (state.selectedCity || state.expandMode || state.selectedRoute) ACTIONS.deselect()
})

// Teclado: Enter/Espaço em cidades do SVG + atalhos do jogo
document.addEventListener('keydown', (event) => {
  const target = event.target
  if ((event.key === 'Enter' || event.key === ' ') && target?.dataset?.action && target.tagName !== 'BUTTON') {
    event.preventDefault()
    ACTIONS[target.dataset.action]?.(target, event)
    return
  }
  if (document.querySelector('dialog[open]') || document.body.dataset.screen !== 'game') return
  if (!$('#turn-overlay').hidden) {
    if (event.key === 'Enter' || event.key === ' ' || event.key === 'Escape') skipWait?.()
    return
  }
  if (event.ctrlKey || event.metaKey || event.altKey) return
  const shortcuts = {
    e: () => toggleExpand($('#act-expand')),
    l: () => openLab($('[data-action="open-lab"]')),
    h: () => openAbility($('[data-action="open-ability"]')),
    r: () => doCollect($('[data-action="collect"]')),
    t: () => endTurn($('#act-end')),
    escape: () => ACTIONS.deselect(),
  }
  const fn = shortcuts[event.key.toLowerCase()]
  if (fn) {
    event.preventDefault()
    fn()
  }
})

// A tela final não fecha com Esc (o jogador escolhe uma opção)
$('#end-dialog').addEventListener('cancel', (event) => event.preventDefault())

// Clicar no fundo escuro fecha diálogos (exceto o final)
document.querySelectorAll('dialog').forEach((dialog) => {
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog && dialog.id !== 'end-dialog') dialog.close()
  })
})

// Efeito de paralaxe suave no mapa
const tilt = $('#map-tilt')
$('#map-stage').addEventListener('pointermove', (event) => {
  if (settings.reduced || event.pointerType !== 'mouse') return
  const rect = event.currentTarget.getBoundingClientRect()
  const rx = (event.clientX - rect.left) / rect.width - 0.5
  const ry = (event.clientY - rect.top) / rect.height - 0.5
  tilt.style.setProperty('--tilt-y', `${(rx * 4).toFixed(2)}deg`)
  tilt.style.setProperty('--tilt-x-extra', `${(-ry * 3).toFixed(2)}deg`)
})

// ---------- Inicialização ----------
hydrateIcons()
buildMap($('#map'))
fx.initBackground($('#bg-canvas'))
applySettings()
render()
replayIntro()
startMenuDemo()
startTraffic(() => state)
