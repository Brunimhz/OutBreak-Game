// =============================================================
// ESTADO CENTRAL DO JOGO
// Toda a partida vive dentro de um único objeto. "Novo Jogo"
// simplesmente cria um estado novo com esta função.
// =============================================================
import { CITIES, CONFIG, EVOLUTIONS, OBJECTIVES } from './data.js'

export function createInitialState() {
  return {
    // setup -> playing -> transition -> victory | defeat
    phase: 'setup',
    currentTurn: 1,
    actionsRemaining: CONFIG.actionsPerTurn,
    dna: CONFIG.startDna,
    score: 0,
    research: 0,

    // status: healthy | infected | contained ("exposta" é calculado)
    // infection = % dos vivos infectados; dead = número absoluto de mortos
    cities: Object.fromEntries(
      CITIES.map((c) => [c.id, { status: 'healthy', infection: 0, containment: 0, dead: 0 }]),
    ),
    ownedRoutes: [],
    originCity: null,
    regionsReached: [],
    evolutions: Object.fromEntries(EVOLUTIONS.map((e) => [e.id, 0])),
    objectives: Object.fromEntries(OBJECTIVES.map((o) => [o.id, false])),

    // Seleção / interface
    selectedCity: null,
    selectedRoute: null, // { routeId, from, to }
    expandMode: false,

    // Eventos e modificadores temporários (duram 1 turno)
    activeEvent: null,
    modifiers: { restrictedRoutes: [], blockedRegion: null },
    bonuses: { freeExpansion: false, extraActionsNextTurn: 0 },
    interferenceUsed: false,

    log: [],
    result: null,
  }
}
