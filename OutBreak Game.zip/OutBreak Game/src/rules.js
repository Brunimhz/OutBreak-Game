// =============================================================
// REGRAS DO JOGO
// Funções que alteram o estado. Cada ação retorna:
//   { ok: true, effects: [...] }  -> a interface usa "effects"
//                                    para tocar animações e sons
//   { ok: false, message }        -> jogada inválida
// =============================================================
import {
  CITIES,
  CITY_BY_ID,
  CONFIG,
  EVENTS,
  EVOLUTIONS,
  EVO_BY_ID,
  OBJECTIVES,
  REGIONS,
  REGION_BY_ID,
  ROUTES,
  ROUTES_BY_CITY,
  TIER_REQUIREMENTS,
} from './data.js'

const success = (effects = []) => ({ ok: true, effects })
const fail = (message) => ({ ok: false, message, effects: [] })
const clamp = (v, min, max) => Math.min(max, Math.max(min, v))
const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)]

function shuffle(arr) {
  const copy = [...arr]
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[copy[i], copy[j]] = [copy[j], copy[i]]
  }
  return copy
}

function addLog(state, text, tone = 'info') {
  state.log.unshift({ turn: state.currentTurn, text, tone })
  if (state.log.length > 40) state.log.length = 40
}

// ---------- Consultas (não alteram o estado) ----------

export const getNeighbors = (cityId) =>
  ROUTES_BY_CITY[cityId].map((r) => (r.a === cityId ? r.b : r.a))

export const getActiveCities = (state) =>
  CITIES.filter((c) => state.cities[c.id].status === 'infected')

export const getReachedCities = (state) =>
  CITIES.filter((c) => state.cities[c.id].status !== 'healthy')

export const countUnlockedEvolutions = (state) =>
  EVOLUTIONS.filter((e) => state.evolutions[e.id] > 0).length

/** Estado visual: healthy | exposed | infected | contained */
export function getCityStatus(state, cityId) {
  const status = state.cities[cityId].status
  if (status !== 'healthy') return status
  const exposed = getNeighbors(cityId).some((n) => state.cities[n].status === 'infected')
  return exposed ? 'exposed' : 'healthy'
}

/** População de uma cidade em pessoas: total, saudáveis, infectados e mortos. */
export function getCityPeople(state, cityId) {
  const total = Math.round(CITY_BY_ID[cityId].population * 1_000_000)
  const cs = state.cities[cityId]
  const dead = Math.min(total, Math.round(cs.dead || 0))
  const alive = total - dead
  const infected = cs.status === 'healthy' ? 0 : Math.round((alive * cs.infection) / 100)
  return { total, dead, infected, healthy: alive - infected }
}

/** Soma da população mundial (contador estilo Plague Inc). */
export function getWorldStats(state) {
  const world = { total: 0, dead: 0, infected: 0, healthy: 0 }
  for (const city of CITIES) {
    const p = getCityPeople(state, city.id)
    world.total += p.total
    world.dead += p.dead
    world.infected += p.infected
    world.healthy += p.healthy
  }
  return world
}

/** Fração dos infectados de uma cidade que morre no próximo fim de turno. */
export function getLethality(state, cityId) {
  const cs = state.cities[cityId]
  if (cs.status === 'healthy') return 0
  const base =
    CONFIG.baseLethality +
    CONFIG.lethalityPerTurn * state.currentTurn +
    (cs.infection >= 80 ? CONFIG.lethalityHighInfection : 0)
  const factor = cs.status === 'contained' ? CONFIG.containedLethalityFactor : 1
  return Math.min(CONFIG.maxLethality, base * factor)
}

export const STATUS_LABELS = {
  healthy: 'Saudável',
  exposed: 'Exposta',
  infected: 'Infectada',
  contained: 'Contida',
}

export function getRouteCost(state, route, toId) {
  if (state.bonuses.freeExpansion) return 0
  const envLevel = state.evolutions.env
  let cost = route.cost
  if (route.cost === 3 && envLevel >= 1) cost -= 1
  if (route.cost === 2 && envLevel >= 2) cost -= 1
  if (state.modifiers.restrictedRoutes.includes(route.id)) cost += 1
  if (state.modifiers.blockedRegion === CITY_BY_ID[toId].region && envLevel < 1) cost += 1
  return Math.max(1, cost)
}

export function getExpansionRewards(state, toId) {
  const globalLevel = state.evolutions.global
  const newRegion = !state.regionsReached.includes(CITY_BY_ID[toId].region)
  return {
    newRegion,
    dna: 1 + globalLevel + (newRegion ? 2 + globalLevel : 0),
    score: CONFIG.cityScore + (newRegion ? CONFIG.regionScore : 0),
    research: Math.max(0, CONFIG.researchPerCity - state.evolutions.silent),
  }
}

/** Lista todas as expansões possíveis: rota de cidade infectada -> cidade saudável */
export function getAvailableExpansions(state) {
  const options = []
  for (const route of ROUTES) {
    const sa = state.cities[route.a].status
    const sb = state.cities[route.b].status
    let from = null
    let to = null
    if (sa === 'infected' && sb === 'healthy') [from, to] = [route.a, route.b]
    else if (sb === 'infected' && sa === 'healthy') [from, to] = [route.b, route.a]
    if (!from) continue
    options.push({
      routeId: route.id,
      route,
      from,
      to,
      cost: getRouteCost(state, route, to),
      rewards: getExpansionRewards(state, to),
    })
  }
  return options.sort(
    (x, y) => x.cost - y.cost || CITY_BY_ID[x.to].name.localeCompare(CITY_BY_ID[y.to].name),
  )
}

export function getRouteBlockReason(state, route) {
  const sa = state.cities[route.a].status
  const sb = state.cities[route.b].status
  if (state.ownedRoutes.includes(route.id)) return 'Esta rota já foi usada pela expansão.'
  if (sa !== 'healthy' && sb !== 'healthy') return 'As duas cidades desta rota já foram alcançadas.'
  if (sa === 'contained' || sb === 'contained')
    return 'A cidade de origem está contida. Use a habilidade Romper Contenção.'
  return 'Nenhuma cidade desta rota está infectada. Expanda a partir do seu território.'
}

export function getEvolutionCost(state, evo) {
  return evo.baseCost + state.evolutions[evo.id] * 3
}

/** Retorna o motivo do bloqueio ou null se a evolução pode ser comprada. */
export function getEvolutionLock(state, evo) {
  const level = state.evolutions[evo.id]
  if (level >= evo.maxLevel) return 'Nível máximo atingido'
  const required = TIER_REQUIREMENTS[evo.tier]
  if (level === 0 && countUnlockedEvolutions(state) < required) {
    return `Requer ${required} ${required === 1 ? 'evolução desbloqueada' : 'evoluções desbloqueadas'}`
  }
  return null
}

export function getCollectAmount(state) {
  const strong = getActiveCities(state).filter((c) => state.cities[c.id].infection >= 60)
  return CONFIG.collectBase + strong.length
}

export function getResearchStatus(value) {
  if (value >= 100) return { label: 'CURA COMPLETA', level: 'cure' }
  if (value >= 90) return { label: 'CRÍTICO', level: 'critical' }
  if (value >= 70) return { label: 'ALERTA', level: 'alert' }
  if (value >= 40) return { label: 'ATENÇÃO', level: 'warn' }
  return { label: 'ESTÁVEL', level: 'stable' }
}

export function getObjectiveProgress(state, id) {
  switch (id) {
    case 'cities':
      return { value: getActiveCities(state).length, target: 10 }
    case 'regions':
      return { value: state.regionsReached.length, target: 3 }
    case 'evolutions':
      return { value: countUnlockedEvolutions(state), target: 3 }
    case 'allRegions':
      return { value: state.regionsReached.length, target: 4 }
    case 'bank':
      return { value: state.dna, target: 15 }
    case 'early':
      return { value: state.currentTurn, target: 11, inverse: true }
    default:
      return { value: 0, target: 1 }
  }
}

// ---------- Mutações internas ----------

function addResearch(state, amount, effects) {
  const before = state.research
  state.research = clamp(state.research + amount, 0, 100)
  const delta = state.research - before
  if (delta !== 0 && effects) effects.push({ type: 'research', amount: delta })
}

function spendDna(state, amount, effects) {
  if (amount <= 0) return
  state.dna -= amount
  effects.push({ type: 'spend', amount })
}

function infectCity(state, cityId, effects, { origin = false } = {}) {
  const city = CITY_BY_ID[cityId]
  const cityState = state.cities[cityId]
  const rewards = getExpansionRewards(state, cityId)

  cityState.status = 'infected'
  cityState.containment = 0
  cityState.infection = origin
    ? CONFIG.originInfection
    : Math.min(100, CONFIG.startInfection + 15 * state.evolutions.fast)

  state.score += CONFIG.cityScore
  effects.push({ type: 'city', cityId })
  effects.push({ type: 'score', amount: CONFIG.cityScore, cityId })

  if (rewards.newRegion) {
    state.regionsReached.push(city.region)
    state.score += CONFIG.regionScore
    effects.push({ type: 'region', regionId: city.region, amount: CONFIG.regionScore })
    addLog(state, `Nova região alcançada: ${REGION_BY_ID[city.region].name}.`, 'good')
  }

  if (!origin) {
    state.dna += rewards.dna
    effects.push({ type: 'dna', amount: rewards.dna, cityId })
    addResearch(state, rewards.research, effects)
  }
}

function completeObjective(state, objective, effects) {
  state.objectives[objective.id] = true
  state.score += CONFIG.objectiveScore
  effects.push({ type: 'objective', id: objective.id, label: objective.label, amount: CONFIG.objectiveScore })
  addLog(state, `Objetivo concluído: ${objective.label}.`, 'good')
}

function checkObjectives(state, effects) {
  if (state.phase === 'victory' || state.phase === 'defeat') return
  for (const objective of OBJECTIVES) {
    if (state.objectives[objective.id] || objective.evaluateAtEnd) continue
    const { value, target } = getObjectiveProgress(state, objective.id)
    if (value >= target) completeObjective(state, objective, effects)
  }
  const mainDone = OBJECTIVES.filter((o) => o.type === 'main').every((o) => state.objectives[o.id])
  if (mainDone) declareVictory(state, effects)
}

function declareVictory(state, effects) {
  // Objetivos bônus avaliados apenas no final
  if (state.currentTurn < 12) completeObjective(state, OBJECTIVES.find((o) => o.id === 'early'), effects)
  if (state.dna >= 15) completeObjective(state, OBJECTIVES.find((o) => o.id === 'bank'), effects)

  const dnaBonus = state.dna * CONFIG.dnaScore
  const efficiency = (CONFIG.maxTurns - state.currentTurn + 1) * CONFIG.efficiencyPerTurn
  const baseScore = state.score
  state.score = baseScore + dnaBonus + efficiency
  state.phase = 'victory'
  state.result = {
    type: 'victory',
    baseScore,
    dnaBonus,
    efficiency,
    finalScore: state.score,
    turns: state.currentTurn,
    dna: state.dna,
    cities: getReachedCities(state).length,
    regions: state.regionsReached.length,
    evolutions: countUnlockedEvolutions(state),
    research: state.research,
    ...pickToll(state),
  }
  addLog(state, 'Todos os objetivos principais foram concluídos!', 'good')
  effects.push({ type: 'victory' })
}

function declareDefeat(state, reason) {
  state.phase = 'defeat'
  if (reason === 'time') state.research = 100
  state.result = {
    type: 'defeat',
    reason,
    finalScore: state.score,
    turns: state.currentTurn,
    cities: getReachedCities(state).length,
    regions: state.regionsReached.length,
    research: state.research,
    ...pickToll(state),
  }
}

function pickToll(state) {
  const { infected, dead } = getWorldStats(state)
  return { infected, dead }
}

function requireAction(state) {
  if (state.phase !== 'playing') return 'Aguarde: a partida não está em andamento.'
  if (state.actionsRemaining <= 0) return 'Sem ações restantes. Encerre o turno.'
  return null
}

// ---------- Ações do jogador ----------

export function startOutbreak(state, cityId) {
  if (state.phase !== 'setup') return fail('A origem já foi escolhida.')
  if (!CITY_BY_ID[cityId]) return fail('Cidade inexistente.')
  const effects = []
  state.phase = 'playing'
  state.originCity = cityId
  infectCity(state, cityId, effects, { origin: true })
  addLog(state, `O surto começou em ${CITY_BY_ID[cityId].name}.`, 'good')
  checkObjectives(state, effects)
  return success(effects)
}

export function expand(state, routeId) {
  const blocked = requireAction(state)
  if (blocked) return fail(blocked)
  const option = getAvailableExpansions(state).find((o) => o.routeId === routeId)
  if (!option) return fail('Esta rota não está disponível.')
  if (state.dna < option.cost) return fail(`DNA insuficiente: esta rota custa ${option.cost} DNA.`)

  const effects = [{ type: 'travel', routeId, from: option.from, to: option.to }]
  spendDna(state, option.cost, effects)
  state.actionsRemaining -= 1
  state.bonuses.freeExpansion = false
  state.ownedRoutes.push(routeId)
  infectCity(state, option.to, effects)
  addLog(
    state,
    `Expansão: ${CITY_BY_ID[option.from].name} → ${CITY_BY_ID[option.to].name} (${option.cost} DNA).`,
  )
  checkObjectives(state, effects)
  return success(effects)
}

const MUTATIONS = [
  { id: 'actions', label: 'Hiperatividade: +2 ações neste turno', apply: (s) => { s.actionsRemaining += 2 } },
  { id: 'dna', label: 'Replicação: +5 DNA', apply: (s, fx) => { s.dna += 5; fx.push({ type: 'dna', amount: 5 }) } },
  { id: 'free', label: 'Salto Silencioso: próxima expansão gratuita', apply: (s) => { s.bonuses.freeExpansion = true } },
  { id: 'research', label: 'Ruído nos Dados: Pesquisa Global −5%', apply: (s, fx) => addResearch(s, -5, fx) },
]

export function evolve(state, evoId) {
  const evo = EVO_BY_ID[evoId]
  if (!evo) return fail('Evolução inexistente.')
  const lock = getEvolutionLock(state, evo)
  if (lock) return fail(lock)
  const blocked = requireAction(state)
  if (blocked) return fail(blocked)
  const cost = getEvolutionCost(state, evo)
  if (state.dna < cost) return fail(`DNA insuficiente: ${evo.name} custa ${cost} DNA.`)

  const effects = []
  spendDna(state, cost, effects)
  state.actionsRemaining -= 1
  state.evolutions[evoId] += 1
  const level = state.evolutions[evoId]
  effects.push({ type: 'evolve', id: evoId, level })
  addLog(state, `Evolução: ${evo.name} (nível ${level}).`, 'good')

  if (evoId === 'mutation') {
    const mutation = pickRandom(MUTATIONS)
    mutation.apply(state, effects)
    effects.push({ type: 'mutation', label: mutation.label })
    addLog(state, `Mutação: ${mutation.label}.`, 'good')
  }

  checkObjectives(state, effects)
  return success(effects)
}

export function collectResources(state) {
  const blocked = requireAction(state)
  if (blocked) return fail(blocked)
  const amount = getCollectAmount(state)
  state.actionsRemaining -= 1
  state.dna += amount
  const strongest = getActiveCities(state).sort(
    (a, b) => state.cities[b.id].infection - state.cities[a.id].infection,
  )[0]
  addLog(state, `Recursos coletados: +${amount} DNA.`)
  const effects = [{ type: 'dna', amount, cityId: strongest?.id }]
  checkObjectives(state, effects)
  return success(effects)
}

export function breachContainment(state, cityId) {
  const blocked = requireAction(state)
  if (blocked) return fail(blocked)
  const cityState = state.cities[cityId]
  if (!cityState || cityState.status !== 'contained') return fail('Esta cidade não está contida.')
  if (state.dna < CONFIG.breachCost) return fail(`DNA insuficiente: custa ${CONFIG.breachCost} DNA.`)

  const effects = []
  spendDna(state, CONFIG.breachCost, effects)
  state.actionsRemaining -= 1
  cityState.status = 'infected'
  cityState.containment = 0
  cityState.infection = Math.max(cityState.infection, 40)
  effects.push({ type: 'city', cityId }, { type: 'breach', cityId })
  addLog(state, `Contenção rompida em ${CITY_BY_ID[cityId].name}.`, 'good')
  checkObjectives(state, effects)
  return success(effects)
}

export function interfereResearch(state) {
  const blocked = requireAction(state)
  if (blocked) return fail(blocked)
  if (state.interferenceUsed) return fail('A Interferência de Dados só pode ser usada uma vez por turno.')
  if (state.research <= 0) return fail('A Pesquisa Global já está em 0%.')
  if (state.dna < CONFIG.interfereCost) return fail(`DNA insuficiente: custa ${CONFIG.interfereCost} DNA.`)

  const effects = []
  spendDna(state, CONFIG.interfereCost, effects)
  state.actionsRemaining -= 1
  state.interferenceUsed = true
  addResearch(state, -CONFIG.interfereAmount, effects)
  addLog(state, `Interferência de Dados: Pesquisa Global −${CONFIG.interfereAmount}%.`, 'good')
  return success(effects)
}

// ---------- Fim de turno (executado em etapas para a animação) ----------

/** Etapa 1: infecção cresce, pesquisa avança e a contenção pode agir. */
export function resolveResearchPhase(state) {
  state.phase = 'transition'
  state.selectedRoute = null
  state.expandMode = false
  state.modifiers = { restrictedRoutes: [], blockedRegion: null }
  state.activeEvent = null

  const before = getWorldStats(state)
  for (const city of CITIES) {
    const lethality = getLethality(state, city.id)
    if (lethality > 0) state.cities[city.id].dead += getCityPeople(state, city.id).infected * lethality
  }

  const growth = 10 + 8 * state.evolutions.fast
  for (const city of CITIES) {
    const cs = state.cities[city.id]
    if (cs.status === 'infected') cs.infection = Math.min(100, cs.infection + growth)
    if (cs.status === 'contained') {
      cs.infection = Math.max(0, cs.infection - 10)
      cs.containment = Math.min(100, cs.containment + 10)
    }
  }

  const active = getActiveCities(state)
  const gain = 2 + Math.floor(active.length / 2) + Math.floor(state.currentTurn / 4)
  addResearch(state, gain)

  // Contenção: cidades com menos de 80% de infecção podem ser contidas
  let contained = null
  if (state.research >= 20 && active.length >= 2) {
    const chance = clamp(0.3 + state.research / 200 - 0.15 * state.evolutions.silent, 0.05, 0.85)
    const candidates = active.filter((c) => state.cities[c.id].infection < 80)
    if (candidates.length && Math.random() < chance) {
      const minInfection = Math.min(...candidates.map((c) => state.cities[c.id].infection))
      const target = pickRandom(candidates.filter((c) => state.cities[c.id].infection === minInfection))
      const cs = state.cities[target.id]
      cs.status = 'contained'
      cs.containment = 60 + Math.floor(Math.random() * 20)
      contained = target.id
      addLog(state, `${target.name} foi contida pela resposta global.`, 'bad')
    }
  }

  const after = getWorldStats(state)
  const newDeaths = after.dead - before.dead
  const newInfected = after.infected - before.infected
  if (newDeaths > 0) addLog(state, `${newDeaths.toLocaleString('pt-BR')} mortes registradas neste turno.`, 'good')

  addLog(state, `Fase de pesquisa: Pesquisa Global +${gain}%.`, 'bad')
  if (state.research >= 100) declareDefeat(state, 'research')
  return { gain, contained, growth, newDeaths, newInfected, world: after }
}

/** Etapa 2: sorteia e aplica um evento global. */
export function resolveEventPhase(state) {
  const effects = []
  const hasContained = CITIES.some((c) => state.cities[c.id].status === 'contained')
  const pool = EVENTS.filter((e) => e.id !== 'breach' || hasContained)
  const totalWeight = pool.reduce((sum, e) => sum + e.weight, 0)
  let roll = Math.random() * totalWeight
  let event = pool[pool.length - 1]
  for (const e of pool) {
    roll -= e.weight
    if (roll <= 0) {
      event = e
      break
    }
  }

  const detail = applyEvent(state, event, effects)
  state.activeEvent = { ...event, detail }
  addLog(state, `Evento: ${event.name}. ${detail}`, event.tone)

  if (state.research >= 100) declareDefeat(state, 'research')
  else checkObjectives(state, effects)
  return { event: state.activeEvent, effects }
}

function applyEvent(state, event, effects) {
  switch (event.id) {
    case 'breakthrough':
      addResearch(state, 5, effects)
      return 'Pesquisa Global +5%.'
    case 'emergency':
      addResearch(state, 3, effects)
      return 'Pesquisa Global +3%.'
    case 'resources':
      state.dna += 3
      effects.push({ type: 'dna', amount: 3 })
      return '+3 DNA adicionados à sua reserva.'
    case 'travel': {
      const available = [...new Set(getAvailableExpansions(state).map((o) => o.routeId))]
      const others = ROUTES.map((r) => r.id).filter((id) => !available.includes(id))
      const ids = [...shuffle(available).slice(0, 2), ...shuffle(others)].slice(0, 4)
      state.modifiers.restrictedRoutes = ids
      return `${ids.length} rotas custam +1 DNA neste turno (marcadas no mapa).`
    }
    case 'breach': {
      const target = pickRandom(CITIES.filter((c) => state.cities[c.id].status === 'contained'))
      const cs = state.cities[target.id]
      cs.status = 'infected'
      cs.containment = 0
      cs.infection = Math.max(cs.infection, 30)
      effects.push({ type: 'city', cityId: target.id })
      return `${target.name} voltou a ficar infectada.`
    }
    case 'blockade': {
      const regions = REGIONS.filter((r) =>
        CITIES.some((c) => c.region === r.id && state.cities[c.id].status === 'healthy'),
      )
      if (!regions.length) return 'Nenhuma região pôde ser bloqueada.'
      const region = pickRandom(regions)
      state.modifiers.blockedRegion = region.id
      return `Rotas para ${region.name} custam +1 DNA neste turno.`
    }
    case 'momentum':
      state.bonuses.extraActionsNextTurn = 1
      return 'Você terá +1 ação no próximo turno.'
    default:
      return 'Nenhum efeito neste turno.'
  }
}

/** Etapa 3: avança para o próximo turno (ou encerra por tempo). */
export function startNextTurn(state) {
  if (state.phase === 'victory' || state.phase === 'defeat') return { passive: 0 }
  if (state.currentTurn >= CONFIG.maxTurns) {
    declareDefeat(state, 'time')
    return { passive: 0 }
  }
  state.currentTurn += 1
  state.actionsRemaining = CONFIG.actionsPerTurn + state.bonuses.extraActionsNextTurn
  state.bonuses.extraActionsNextTurn = 0
  state.interferenceUsed = false
  const passive = Math.floor(getActiveCities(state).length / 3)
  state.dna += passive
  state.phase = 'playing'
  if (passive > 0) addLog(state, `Renda passiva: +${passive} DNA.`)
  return { passive }
}
